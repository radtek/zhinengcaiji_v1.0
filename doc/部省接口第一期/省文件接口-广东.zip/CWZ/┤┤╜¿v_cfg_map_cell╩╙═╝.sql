create view v_cfg_map_cell as
select distinct ne_omc_id,ne_bsc_id,ne_bts_id,ne_cell_id,omc,bsc,bts,cell,adm_area,county_name,omc_name,bsc_name,bts_name,
cell_name,city_id,city_name,vendor,vendorname,pn,localbts from cfg_map_dev_to_ne
