
delete from CFG_PROVICE_PERF
where datatype in(13,14);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '1', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2003, null, 'ʡ��', '''{1}''', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2004, null, '����', 'orimap.CITY_NAME', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8072, null, 'Դ��������MSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8073, null, 'Դ��������MGW��ʶ', null, 'ZY0810', null, '8', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1001, null, 'Դʡ�ʱ߽�������ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1002, null, 'ʱ���', '''{0}''', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1003, null, 'Դʡ�ʱ߽���������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(orimap.cell_name, '','', ''��'') end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1004, null, 'ʡ��', '''{1}''', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1005, null, '����', 'orimap.CITY_NAME', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1006, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1007, null, 'Դ��������MGW��ʶ', null, 'ZY0804', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1008, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1009, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1010, null, 'Դ�������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1011, null, 'Դpn', 'orimap.PN', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1012, null, '����˳��', 'LINKCELL.sequence_b', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1013, null, '�л�����', null, 'ZY0804', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1009, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1010, null, 'Դ�������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1011, null, 'Դpn', 'orimap.PN', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1012, null, '����˳��', 'LUC.SN', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1013, null, '�л�����', null, 'ZY0810', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1014, null, '��������ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2014, null, 'Դpn', 'orimap.PN', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2015, null, '����˳��', 'DFNBRCH.DFRSN', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2016, null, '�л�����', null, 'ZY0808', null, '1', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2020, null, '����������MGW��ʶ', null, 'ZY0808', null, '1', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2006, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '1', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2028, null, '��pn', 'neimap.PN', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1015, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1016, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1017, null, '����������MGW��ʶ', null, 'ZY0810', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3014, null, 'Դpn', 'orimap.PN', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3015, null, '����˳��', 'SFNBRCH.SFRSN', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3016, null, '�л�����', null, 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3020, null, '����������MGW��ʶ', null, 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3028, null, '��pn', 'neimap.PN', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4003, null, 'ʡ��', '''{1}''', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4004, null, '����', 'orimap.CITY_NAME', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4006, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4014, null, 'Դpn', 'orimap.PN', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4015, null, '����˳��', 'DFNBRCH.DFRSN', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4016, null, '�л�����', null, 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '2', 'DF', 1, 14);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4020, null, '����������MGW��ʶ', null, 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4028, null, '��pn', 'neimap.PN', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2002, null, 'ʱ���', '''{0}''', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2003, null, 'ʡ��', '''{1}''', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2004, null, '����', 'orimap.CITY_NAME', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2006, null, 'Դ��������MGW��ʶ', null, 'ZY0804', null, '2', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2014, null, 'Դpn', 'orimap.PN', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2015, null, '����˳��', 'ZTE.sequence_b', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2016, null, '�л�����', null, 'ZY0804', null, '2', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2020, null, '����������MGW��ʶ', null, 'ZY0804', null, '2', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2028, null, '��pn', 'neimap.PN', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0804', null, '2', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1002, null, 'ʱ���', '''{0}''', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1003, null, 'ʡ��', '''{1}''', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1004, null, '����', 'orimap.CITY_NAME', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1006, null, 'Դ��������MGW��ʶ', null, 'ZY0804', null, '1', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1014, null, 'Դpn', 'orimap.PN', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1015, null, '����˳��', 'ZTE.sequence_b', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1016, null, '�л�����', null, 'ZY0804', null, '1', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1020, null, '����������MGW��ʶ', null, 'ZY0804', null, '1', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1028, null, '��pn', 'neimap.PN', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0804', null, '1', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2001, null, 'Դʡ�ʱ߽�������ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1035, 'MP1.7.1.1.2', '������Ƶ', 'SFNBRCH.NBRCDMACH', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1036, 'MP1.7.1.1.3', 'ͬƵ���ȼ�', 'SFNBRCH.SFRSN', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1037, 'MP1.7.1.2.1', '������Ƶ', 'SFNBRCH_SFNBRPARA.CCDMACH', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1038, 'MP1.7.1.2.2', '������Ƶ', 'SFNBRCH_SFNBRPARA.NBRCDMACH', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1039, 'MP1.7.1.2.3', '�Ƿ�������ڼ���֧�������ڴ�С', 'SFNBRCH_SFNBRPARA.NSRCHWININC', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1040, 'MP1.7.1.2.4', '���ڼ���֧�������ڴ�С', 'SFNBRCH_SFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1041, 'MP1.7.1.2.5', '�Ƿ�������ڼ���֧��������ƫ��', 'SFNBRCH_SFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1042, 'MP1.7.1.2.6', '���ڼ���֧��������ƫ��', 'SFNBRCH_SFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1043, 'MP1.7.1.2.7', '�������ȼ�', 'SFNBRCH_SFNBRPARA.SRCHP', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2034, 'MP1.7.1.3.1', '������Ƶ', 'DFNBRCH.CCDMACH', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2035, 'MP1.7.1.3.2', '������Ƶ', 'DFNBRCH.NBRCDMACH', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2036, 'MP1.7.1.3.3', '��Ƶ���ȼ�', 'DFNBRCH.DFRSN', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2037, 'MP1.7.1.4.1', '������Ƶ', 'DFNBRCH_DFNBRPARA.CCDMACH', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2038, 'MP1.7.1.4.2', '������Ƶ', 'DFNBRCH_DFNBRPARA.NBRCDMACH', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1034, 'MP1.7.1.1.1', '������Ƶ', 'SFNBRCH.CCDMACH', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2039, 'MP1.7.1.4.3', '������', 'DFNBRCH_DFNBRPARA.SRCHSET', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2040, 'MP1.7.1.4.4', '���ڼ���֧�������ڴ�С', 'DFNBRCH_DFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '1', 'DF', 1, 14);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2041, 'MP1.7.1.4.5', '�Ƿ�������ڼ���֧��������ƫ��', 'DFNBRCH_DFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2042, 'MP1.7.1.4.6', '���ڼ���֧��������ƫ��', 'DFNBRCH_DFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2043, 'MP1.7.1.4.7', '�������ȼ�', 'DFNBRCH_DFNBRPARA.SRCHP', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3034, 'MP1.7.2.1.1', '������Ƶ', 'SFNBRCH.CCDMACH', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3035, 'MP1.7.2.1.2', '������Ƶ', 'SFNBRCH.NBRCDMACH', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3036, 'MP1.7.2.1.3', 'ͬƵ���ȼ�', 'SFNBRCH.SFRSN', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3037, 'MP1.7.2.2.1', '������Ƶ', 'SFNBRCH_SFNBRPARA.CCDMACH', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3038, 'MP1.7.2.2.2', '������Ƶ', 'SFNBRCH_SFNBRPARA.NBRCDMACH', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3039, 'MP1.7.2.2.3', '�Ƿ�������ڼ���֧�������ڴ�С', 'SFNBRCH_SFNBRPARA.NSRCHWININC', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3040, 'MP1.7.2.2.4', '���ڼ���֧�������ڴ�С', 'SFNBRCH_SFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3041, 'MP1.7.2.2.5', '�Ƿ�������ڼ���֧��������ƫ��', 'SFNBRCH_SFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3042, 'MP1.7.2.2.6', '���ڼ���֧��������ƫ��', 'SFNBRCH_SFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3043, 'MP1.7.2.2.7', '�������ȼ�', 'SFNBRCH_SFNBRPARA.SRCHP', 'ZY0808', null, '2', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3044, 'MP1.7.2.3.1', '������Ƶ', 'SFNBRCH_ODOSFNBRPARA.CCDMACH', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3045, 'MP1.7.2.3.2', '������Ƶ', 'SFNBRCH_ODOSFNBRPARA.NBRCDMACH', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3046, 'MP1.7.2.3.3', '�Ƿ�������ڼ���֧�������ڴ�С', 'SFNBRCH_ODOSFNBRPARA.NSRCHWININC', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3047, 'MP1.7.2.3.4', '���ڼ���֧�������ڴ�С', 'SFNBRCH_ODOSFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3048, 'MP1.7.2.3.5', '�Ƿ�������ڼ���֧��������ƫ��', 'SFNBRCH_ODOSFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3049, 'MP1.7.2.3.6', '���ڼ���֧��������ƫ��', 'SFNBRCH_ODOSFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4034, 'MP1.7.2.4.1', '������Ƶ', 'DFNBRCH.CCDMACH', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4035, 'MP1.7.2.4.2', '������Ƶ', 'DFNBRCH.NBRCDMACH', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4036, 'MP1.7.2.4.3', '��Ƶ���ȼ�', 'DFNBRCH.DFRSN', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4037, 'MP1.7.2.5.1', '������Ƶ', 'DFNBRCH_DFNBRPARA.CCDMACH', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4038, 'MP1.7.2.5.2', '������Ƶ', 'DFNBRCH_DFNBRPARA.NBRCDMACH', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4039, 'MP1.7.2.5.3', '������', 'DFNBRCH_DFNBRPARA.SRCHSET', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4040, 'MP1.7.2.5.4', '���ڼ���֧�������ڴ�С', 'DFNBRCH_DFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4041, 'MP1.7.2.5.5', '�Ƿ�������ڼ���֧��������ƫ��', 'DFNBRCH_DFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4042, 'MP1.7.2.5.6', '���ڼ���֧��������ƫ��', 'DFNBRCH_DFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4043, 'MP1.7.2.5.7', '�������ȼ�', 'DFNBRCH_DFNBRPARA.SRCHP', 'ZY0808', null, '2', 'DF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4044, 'MP1.7.2.6.1', '������Ƶ', 'DFNBRCH_ODODFNBRPARA.CCDMACH', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4045, 'MP1.7.2.6.2', '������Ƶ', 'DFNBRCH_ODODFNBRPARA.NBRCDMACH', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4046, 'MP1.7.2.6.3', '�Ƿ�������ڼ���֧�������ڴ�С', 'DFNBRCH_ODODFNBRPARA.NSRCHWININC', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4047, 'MP1.7.2.6.4', '���ڼ���֧�������ڴ�С', 'DFNBRCH_ODODFNBRPARA.NSRCHWINSIZE', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4048, 'MP1.7.2.6.5', '�Ƿ�������ڼ���֧��������ƫ��', 'DFNBRCH_ODODFNBRPARA.NSRCHWINOFFSETINC', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (4049, 'MP1.7.2.6.6', '���ڼ���֧��������ƫ��', 'DFNBRCH_ODODFNBRPARA.NSRCHWINOFFSET', 'ZY0808', null, '2', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1028, 'MP4.11.1.1.1', 'ncs_c', 'LUC.ncs_c', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1029, 'MP4.11.1.1.2', 'nghbrantf', 'LUC.nghbrantf', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1030, 'MP4.11.1.1.3', 'pilot_pn', 'LUC.pilot_pn', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1031, 'MP4.11.1.1.4', 'pgn_c', 'LUC.pgn_c', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1032, 'MP4.11.1.1.5', 'nghb_conf', 'LUC.nghb_conf', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1033, 'MP4.11.1.1.6', 'hdhandoff', 'LUC.hdhandoff', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1034, 'MP4.11.1.1.7', 'dcs_c', 'LUC.dcs_c', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1035, 'MP4.11.1.1.8', 'ecp_c', 'LUC.ecp_c', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1036, 'MP4.11.1.1.9', 'sid_c', 'LUC.sid_c', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2002, null, 'ʱ���', '''{0}''', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2003, null, 'Դʡ�ʱ߽���������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(orimap.cell_name, '','', ''��'') end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2004, null, 'ʡ��', '''{1}''', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2005, null, '����', 'orimap.CITY_NAME', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2006, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2007, null, 'Դ��������MGW��ʶ', null, 'ZY0810', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2008, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2009, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2010, null, 'Դ�������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2011, null, 'Դpn', 'orimap.PN', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2012, null, '����˳��', 'LUC.NBRID', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2013, null, '�л�����', null, 'ZY0810', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2014, null, '��������ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2015, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2016, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2017, null, '����������MGW��ʶ', null, 'ZY0810', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2018, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2019, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2020, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2021, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2022, null, '��pn', 'neimap.PN', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0810', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2028, 'MP4.11.2.1.1', 'hdrsnid', 'LUC.hdrsnid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2029, 'MP4.11.2.1.2', 'fmsframeid', 'LUC.fmsframeid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2030, 'MP4.11.2.1.3', 'cellsiteid', 'LUC.cellsiteid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2031, 'MP4.11.2.1.4', 'sectorid', 'LUC.sectorid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2032, 'MP4.11.2.1.5', 'nbrid', 'LUC.nbrid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2033, 'MP4.11.2.1.6', 'nbrnbrhdrcellsiteid', 'LUC.nbrnbrhdrcellsiteid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2034, 'MP4.11.2.1.7', 'nbrnbrsectorid', 'LUC.nbrnbrsectorid', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2035, 'MP4.11.2.1.8', 'nbrwithinsn', 'LUC.nbrwithinsn', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2036, 'MP4.11.2.1.9', 'nbrpnoff', 'LUC.nbrpnoff', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2037, 'MP4.11.2.1.10', 'nbrsystemtype', 'LUC.nbrsystemtype', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2038, 'MP4.11.2.1.11', 'nbrbandclass', 'LUC.nbrbandclass', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2039, 'MP4.11.2.1.12', 'nbrbandsubclass', 'LUC.nbrbandsubclass', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2040, 'MP4.11.2.1.13', 'nbrchannelnumber', 'LUC.nbrchannelnumber', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2041, 'MP4.11.2.1.14', 'nbrsearchwindowsize', 'LUC.nbrsearchwindowsize', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2042, 'MP4.11.2.1.15', 'nbrsearchwindowsizecarrier', 'LUC.nbrsearchwindowsizecarrier', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2043, 'MP4.11.2.1.16', 'nbrsearchwindowsizecarrier2', 'LUC.nbrsearchwindowsizecarrier2', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2044, 'MP4.11.2.1.17', 'nbrsearchwindowsizecarrier3', 'LUC.nbrsearchwindowsizecarrier3', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2045, 'MP4.11.2.1.18', 'nbrsearchwindowsizecarrier4', 'LUC.nbrsearchwindowsizecarrier4', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2046, 'MP4.11.2.1.19', 'nbrsearchwindowsizecarrier5', 'LUC.nbrsearchwindowsizecarrier5', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2047, 'MP4.11.2.1.20', 'nbrsectorasocactiveapipaddress', 'LUC.nbrsectorasocactiveapipaddress', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2048, 'MP4.11.2.1.21', 'nbrsectorasocbackupapipaddress', 'LUC.nbrsectorasocbackupapipaddress', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2049, 'MP4.11.2.1.22', 'nbrchannelnumber2', 'LUC.nbrchannelnumber2', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2050, 'MP4.11.2.1.23', 'nbrchannelnumber3', 'LUC.nbrchannelnumber3', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1010, null, 'Դ�������', 'case BSC.vendor when ''ZY0808'' then SECTOR.SECTOR_ID when ''ZY0804'' then SECTOR.SECTOR_ID when ''ZY0810'' then SECTOR.SECTOR_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1011, null, 'Դpn', 'SECTOR.PN', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1012, null, '����˳��', 'para_sort.sortnum', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1013, null, '�л�����', null, 'ZY0808', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1014, null, '��������ʶ', 'case NEIBSC.vendor when ''ZY0808'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0804'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0810'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1015, null, '������������', 'replace(NEIADM.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1016, null, '����������MSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '1', null, 1, 13);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1017, null, '����������MGW��ʶ', null, 'ZY0808', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1018, null, '����������BSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1019, null, '����������BTS��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1020, null, '���������', 'case NEIBSC.vendor when ''ZY0808'' then NEISECTOR.SECTOR_ID when ''ZY0804'' then NEISECTOR.SECTOR_ID when ''ZY0810'' then NEISECTOR.SECTOR_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1021, null, '����������', 'case NEIBSC.vendor when ''ZY0808'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1022, null, '��pn', 'NEISECTOR.PN', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2051, 'MP4.11.2.1.24', 'nbrchannelnumber4', 'LUC.nbrchannelnumber4', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2052, 'MP4.11.2.1.25', 'nbrchannelnumber5', 'LUC.nbrchannelnumber5', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2053, 'MP4.11.2.1.26', 'nbrbandclass2', 'LUC.nbrbandclass2', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2054, 'MP4.11.2.1.27', 'nbrbandclass3', 'LUC.nbrbandclass3', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2055, 'MP4.11.2.1.28', 'nbrbandclass4', 'LUC.nbrbandclass4', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2056, 'MP4.11.2.1.29', 'nbrbandclass5', 'LUC.nbrbandclass5', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2057, 'MP4.11.2.1.30', 'nbrbandsubclass2', 'LUC.nbrbandsubclass2', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2058, 'MP4.11.2.1.31', 'nbrbandsubclass3', 'LUC.nbrbandsubclass3', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2003, null, 'Դʡ�ʱ߽���������', 'case BSC.vendor when ''ZY0808'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(SECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2004, null, 'ʡ��', '''{1}''', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2005, null, '����', 'CITY.CITY_NAME', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2006, null, 'Դ��������MSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2007, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2008, null, 'Դ��������BSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2009, null, 'Դ��������BTS��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0804'' then MSC.BSCNAME || ''.'' || BTS.BTS_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2010, null, 'Դ�������', 'case BSC.vendor when ''ZY0808'' then SECTOR.SECTOR_ID when ''ZY0804'' then SECTOR.SECTOR_ID when ''ZY0810'' then SECTOR.SECTOR_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2011, null, 'Դpn', 'SECTOR.PN', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2012, null, '����˳��', 'para_sort.sortnum', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2013, null, '�л�����', null, 'ZY0808', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2014, null, '��������ʶ', 'case NEIBSC.vendor when ''ZY0808'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0804'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0810'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2015, null, '������������', 'replace(NEIADM.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2016, null, '����������MSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2017, null, '����������MGW��ʶ', null, 'ZY0808', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2018, null, '����������BSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2019, null, '����������BTS��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2020, null, '���������', 'case NEIBSC.vendor when ''ZY0808'' then NEISECTOR.SECTOR_ID when ''ZY0804'' then NEISECTOR.SECTOR_ID when ''ZY0810'' then NEISECTOR.SECTOR_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2021, null, '����������', 'case NEIBSC.vendor when ''ZY0808'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2022, null, '��pn', 'NEISECTOR.PN', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1001, null, 'Դʡ�ʱ߽�������ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bscname || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1002, null, 'ʱ���', '''{0}''', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1003, null, 'Դʡ�ʱ߽���������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(orimap.cell_name, '','', ''��'') end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1004, null, 'ʡ��', '''{1}''', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1005, null, '����', 'orimap.city_name', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1006, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1007, null, 'Դ��������MGW��ʶ', null, 'ZY0810', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1008, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8074, null, 'Դ��������BSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8075, null, 'Դ��������BTS��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0804'' then MSC.BSCNAME || ''.'' || BTS.BTS_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8076, null, 'Դ��������������ʶ', 'case BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || BSC.CHINA_NAME || ''.'' ||BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0804'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0810'' then MSC.MSCNAME || ''.'' || BSC.CHINA_NAME || ''.'' ||BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8077, null, 'Դ����������������', 'case BSC.vendor when ''ZY0808'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then         replace(SECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8078, null, 'Դ�������', 'case BSC.vendor when ''ZY0808'' then SECTOR.SECTOR_ID when ''ZY0804'' then SECTOR.SECTOR_ID when ''ZY0810'' then SECTOR.SECTOR_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8079, null, 'Դ�ز����', 'carr.carr_seq', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8080, null, 'Դ�ز�Ƶ��', 'carr.carrier_id', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8081, null, 'Դpn', 'SECTOR.PN', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8082, null, '����˳��', 'para_sort.sortnum', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8083, null, '�л�����', null, 'ZY0810', null, '8', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8084, null, '��������ʶ', 'case NEIBSC.vendor when ''ZY0808'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' ||NEISECTOR.SECTOR_ID when ''ZY0804'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' ||NEISECTOR.SECTOR_ID when ''ZY0810'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' ||NEISECTOR.SECTOR_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8085, null, '������������', 'replace(NEIADM.COUNTY_NAME, ''��'', '''')', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8086, null, '����������MSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8087, null, '����������MGW��ʶ', null, 'ZY0810', null, '8', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8088, null, '����������BSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8089, null, '����������BTS��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8090, null, '���������', 'case BSC.vendor when ''ZY0808'' then NEISECTOR.SECTOR_ID when ''ZY0804'' then NEISECTOR.SECTOR_ID when ''ZY0810'' then NEISECTOR.SECTOR_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8091, null, '����������', 'case NEIBSC.vendor when ''ZY0808'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8092, null, '���ز���ʶ', 'NEICARR.CARR_SEQ', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8093, null, '���ز�Ƶ��', 'NEICARR.CARRIER_ID', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8094, null, '��pn', 'NEISECTOR.PN', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8095, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8096, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8097, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8098, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8099, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0810', null, '8', null, null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1034, 'MP2.7.1.1.1', 'bssid', 'ZTE.bssid', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1035, 'MP2.7.1.1.2', 'system', 'ZTE.system', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1036, 'MP2.7.1.1.3', 'cellid', 'ZTE.cellid', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1037, 'MP2.7.1.1.4', 'pilot_pn', 'ZTE.pilot_pn', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1038, 'MP2.7.1.1.5', 'carrierid', 'ZTE.carrierid', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1039, 'MP2.7.1.1.6', 'mscid', 'ZTE.mscid', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1040, 'MP2.7.1.1.7', 'ci', 'ZTE.ci', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1041, 'MP2.7.1.1.8', 'officeid', 'ZTE.officeid', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1042, 'MP2.7.1.1.9', '������Ƶ����', 'ZTE.nghbr_config', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1043, 'MP2.7.1.1.10', '������Ƶ�������ȼ�', 'ZTE.search_priority', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1044, 'MP2.7.1.1.11', '��Ƶ��������С', 'ZTE.srch_win_nghbr', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1045, 'MP2.7.1.1.12', 'Ƶ�ʰ���ָʾ', 'ZTE.freq_incl', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1046, 'MP2.7.1.1.13', '����Ƶ�����', 'ZTE.nghbr_band', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1047, 'MP2.7.1.1.14', '����Ƶ��', 'ZTE.nghbr_freq', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1048, 'MP2.7.1.1.15', '�ɷ��������л�', 'ZTE.access_entry_ho', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1049, 'MP2.7.1.1.16', '�ɷ�����л�', 'ZTE.access_ho_allowed', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1050, 'MP2.7.1.1.17', '����ʱ����Ϣ����ָʾ��', 'ZTE.timing_incl', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2059, 'MP4.11.2.1.32', 'nbrbandsubclass4', 'LUC.nbrbandsubclass4', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2060, 'MP4.11.2.1.33', 'nbrbandsubclass5', 'LUC.nbrbandsubclass5', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2061, 'MP4.11.2.1.34', 'directedifhotarget', 'LUC.directedifhotarget', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2062, 'MP4.11.2.1.35', 'directedifhotarget2', 'LUC.directedifhotarget2', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2063, 'MP4.11.2.1.36', 'directedifhotarget3', 'LUC.directedifhotarget3', 'ZY0810', null, '2', null, 1, 13);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2064, 'MP4.11.2.1.37', 'directedifhotarget4', 'LUC.directedifhotarget4', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2065, 'MP4.11.2.1.38', 'directedifhotarget5', 'LUC.directedifhotarget5', 'ZY0810', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2001, null, 'Դʡ�ʱ߽�������ʶ', 'case BSC.vendor when ''ZY0808'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0804'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0810'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID end', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2042, 'MP2.7.2.1.9', 'CI', 'ZTE.CI', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1001, null, 'Դʡ�ʱ߽�������ʶ', 'case BSC.vendor when ''ZY0808'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0804'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0810'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1003, null, 'Դʡ�ʱ߽���������', 'case BSC.vendor when ''ZY0808'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(SECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1004, null, 'ʡ��', '''{1}''', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1005, null, '����', 'CITY.CITY_NAME', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1006, null, 'Դ��������MSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1007, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1008, null, 'Դ��������BSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1009, null, 'Դ��������BTS��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0804'' then MSC.BSCNAME || ''.'' || BTS.BTS_ID end', 'ZY0808', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1051, 'MP2.7.1.1.18', '��������ʱ��ƫ��', 'ZTE.nghbr_tx_offset', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1052, 'MP2.7.1.1.19', '����������ÿ�����ڵ�ʱ��', 'ZTE.nghbr_tx_duration', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1053, 'MP2.7.1.1.20', '��������ʱ��', 'ZTE.nghbr_tx_period', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1054, 'MP2.7.1.1.21', '������Ƶ������Ϣ����ָʾ', 'ZTE.add_pilot_rec_incl', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1055, 'MP2.7.1.1.22', '������Ƶ��Ϣ��¼����', 'ZTE.nghbr_pilot_rec_type', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1056, 'MP2.7.1.1.23', '������Ƶ��������С��ƫ��', 'ZTE.srch_offset_nghbr', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1057, 'MP2.7.1.1.24', 'sequence_b', 'ZTE.sequence_b', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1058, 'MP2.7.1.1.25', 'locked_b', 'ZTE.locked_b', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1059, 'MP2.7.1.1.26', 'alias_b', 'ZTE.alias_b', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1060, 'MP2.7.1.1.27', 'ncell_bs_id', 'ZTE.ncell_bs_id', 'ZY0804', null, '1', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2034, 'MP2.7.2.1.1', 'PILOTPN', 'ZTE.PILOTPN', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2035, 'MP2.7.2.1.2', 'SYSTEMTYPE', 'ZTE.SYSTEMTYPE', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2036, 'MP2.7.2.1.3', 'BANDCLASS', 'ZTE.BANDCLASS', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2037, 'MP2.7.2.1.4', 'ChannelNumber', 'ZTE.ChannelNumber', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2038, 'MP2.7.2.1.5', 'SEARCHWINDOWSIZE', 'ZTE.SEARCHWINDOWSIZE', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2039, 'MP2.7.2.1.6', 'SEARCHWINDOWOFFSET', 'ZTE.SEARCHWINDOWOFFSET', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2040, 'MP2.7.2.1.7', 'BCSubnet', 'ZTE.BCSubnet', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2041, 'MP2.7.2.1.8', 'sequence_b', 'ZTE.sequence_b', 'ZY0804', null, '2', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8067, null, 'Դʡ�ʱ߽�������ʶ', 'case BSC.vendor when ''ZY0808'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0804'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0810'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8068, null, 'ʱ���', '''{0}''', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8069, null, 'Դʡ�ʱ߽���������', 'case BSC.vendor when ''ZY0808'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then         replace(SECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8070, null, 'ʡ��', '''{1}''', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (8071, null, '����', 'CITY.CITY_NAME', 'ZY0810', null, '8', null, 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2022, null, '��pn', 'NEISECTOR.PN', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0804', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1028, 'MP2.11.1.1.1', '��ƵPN����ƫ��', 'LINKCELL.pilot_pn', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1029, 'MP2.11.1.1.2', '����С������', 'LINKCELL.ncelltype', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1030, 'MP2.11.1.1.3', '����С�������', 'LINKCELL.ncellofficeid', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1031, 'MP2.11.1.1.4', '����С��BTS��', 'LINKCELL.ncellsystemid', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1032, 'MP2.11.1.1.5', '����С��Cell��', 'LINKCELL.ncellid', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1033, 'MP2.11.1.1.6', '����ȫ�ֱ�ʾ', 'LINKCELL.gncellid', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1044, 'MP2.11.1.1.7', 'С��ʶ�����ʽ', 'LINKCELL.ci_discriminator', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1055, 'MP2.11.1.1.8', '����λ���������', 'LINKCELL.lac', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1056, 'MP2.11.1.1.9', 'С��ʶ��', 'LINKCELL.ci', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1057, 'MP2.11.1.1.10', '�г���', 'LINKCELL.marketid', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1058, 'MP2.11.1.1.11', '������', 'LINKCELL.switchnumber', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1059, 'MP2.11.1.1.12', 'Э��汾��', 'LINKCELL.p_rev', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1060, 'MP2.11.1.1.13', 'С��ģʽ', 'LINKCELL.ncellmode', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1061, 'MP2.11.1.1.14', 'PTT���ȷ�����ID��', 'LINKCELL.dla_id', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1062, 'MP2.11.1.1.15', 'ncell_bs_id', 'LINKCELL.ncell_bs_id', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1063, 'MP2.11.1.1.16', 'alias����', 'LINKCELL.alias_b', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1064, 'MP2.11.1.1.17', 'sequence_b', 'LINKCELL.sequence_b', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0808', null, '1', 'DF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1018, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1019, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.cell when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.cell end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1020, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1021, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1022, null, '��pn', 'neimap.PN', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0810', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0810', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2001, null, 'Դʡ�ʱ߽�������ʶ', 'case BSC.vendor when ''ZY0808'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0804'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID when ''ZY0810'' then BSC.CHINA_NAME || ''.'' || BTS.BTS_ID || ''.'' || SECTOR.SECTOR_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1014, null, '��������ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1015, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1016, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1017, null, '����������MGW��ʶ', null, 'ZY0804', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1018, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1019, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1003, null, 'ʡ��', '''{1}''', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1004, null, '����', 'orimap.CITY_NAME', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1006, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '1', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1007, null, 'Դ��������BSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME      end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1008, null, 'Դ��������BTS��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || orimap.bts when ''ZY0804'' then MSC.BSCNAME || ''.'' || orimap.bts end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1009, null, 'Դ��������������ʶ', 'case orimap.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell when ''ZY0810'' then MSC.MSCNAME || ''.'' || orimap.bsc_name || ''.'' ||orimap.bts || ''.'' || orimap.cell end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1010, null, 'Դ����������������', 'case orimap.vendor when ''ZY0808'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(orimap.cell_name, '','', ''��'') when ''ZY0810'' then         replace(orimap.cell_name, '','', ''��'') end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1011, null, 'Դ���������������', 'case orimap.vendor when ''ZY0808'' then orimap.cell when ''ZY0804'' then orimap.cell when ''ZY0810'' then orimap.cell end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1012, null, 'Դ�ز����', 'orimap.carr_seq', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1013, null, 'Դ�ز�Ƶ��', 'orimap.carr', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1014, null, 'Դpn', 'orimap.PN', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1015, null, '����˳��', 'SFNBRCH.SFRSN', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1016, null, '�л�����', null, 'ZY0808', null, '1', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1017, null, '�����ȱ�ʶ', 'case neimap.vendor when ''ZY0808'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr when ''ZY0810'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' ||neimap.cell||''.''||neimap.carr end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1018, null, '������������', 'replace(neimap.COUNTY_NAME, ''��'', '''')', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1019, null, '����������MSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1020, null, '����������MGW��ʶ', null, 'ZY0808', null, '1', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1021, null, '����������BSC��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then          NEIMSC.BSCNAME end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1022, null, '����������BTS��ʶ', 'CASE neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || neimap.bts when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || neimap.bts end', 'ZY0808', null, '1', 'SF', 1, 14);
commit;
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1023, null, '����������������ʶ', 'case neimap.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell when ''ZY0804'' then neimap.bsc_name || ''.'' || neimap.bts || ''.'' || neimap.cell when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || neimap.bsc_name || ''.'' ||neimap.bts || ''.'' || neimap.cell end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1024, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1025, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1026, null, '���ز���ʶ', 'neimap.CARR_SEQ', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1027, null, '���ز�Ƶ��', 'neimap.carr', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1028, null, '��pn', 'neimap.PN', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1029, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1030, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1031, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1032, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0808', null, '1', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1033, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0808', null, '1', 'SF', null, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3001, null, 'Դʡ�ʱ߽����ȱ�ʶ', 'case orimap.vendor when ''ZY0808'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0804'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr when ''ZY0810'' then orimap.bsc_name || ''.'' || orimap.bts || ''.'' || orimap.cell||''.''||orimap.carr end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3002, null, 'ʱ���', '''{0}''', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3003, null, 'ʡ��', '''{1}''', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3004, null, '����', 'orimap.CITY_NAME', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1020, null, '���������', 'case neimap.vendor when ''ZY0808'' then neimap.cell when ''ZY0804'' then neimap.cell when ''ZY0810'' then neimap.cell end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1021, null, '����������', 'case neimap.vendor when ''ZY0808'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0804'' then replace(neimap.cell_name, '','', ''��'') when ''ZY0810'' then replace(neimap.cell_name, '','', ''��'') end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1022, null, '��pn', 'neimap.PN', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1023, null, '����������ʡ', 'NEITZCELL.PROVINCE', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1024, null, '��������������', 'NEITZCELL.CITY_NAME', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1025, null, '�������߽�����', 'case NEITZCELL.BORDER_TYPE when ''�Ǳ߽�'' then ''0'' when ''ʡ�ʱ߽�'' then ''1'' when ''ʡ�ڱ߽�'' then ''2'' when ''ͬΪʡ��ʡ�ڱ߽�'' then ''3'' end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1026, null, '��������������', 'case neitzcell.vendor when ''ZY0808'' then ''��Ϊ'' when ''ZY0804'' then ''����'' when ''ZY0810'' then ''��Ѷ'' end', 'ZY0804', null, '1', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (1027, null, '�Ƿ�Ϊ�ⲿ����', null, 'ZY0804', null, '1', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2002, null, 'ʱ���', '''{0}''', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2003, null, 'Դʡ�ʱ߽���������', 'case BSC.vendor when ''ZY0808'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(SECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(SECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2004, null, 'ʡ��', '''{1}''', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2005, null, '����', 'CITY.CITY_NAME', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2006, null, 'Դ��������MSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2007, null, 'Դ��������MGW��ʶ', null, 'ZY0804', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2008, null, 'Դ��������BSC��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME when ''ZY0804'' then MSC.BSCNAME end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2009, null, 'Դ��������BTS��ʶ', 'CASE BSC.vendor when ''ZY0808'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0810'' then MSC.MSCNAME || ''.'' || MSC.BSCNAME || ''.'' || BTS.BTS_ID when ''ZY0804'' then MSC.BSCNAME || ''.'' || BTS.BTS_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2010, null, 'Դ�������', 'case BSC.vendor when ''ZY0808'' then SECTOR.SECTOR_ID when ''ZY0804'' then SECTOR.SECTOR_ID when ''ZY0810'' then SECTOR.SECTOR_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2011, null, 'Դpn', 'SECTOR.PN', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2012, null, '����˳��', 'para_sort.sortnum', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2013, null, '�л�����', null, 'ZY0804', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2014, null, '��������ʶ', 'case NEIBSC.vendor when ''ZY0808'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0804'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID when ''ZY0810'' then NEIBSC.CHINA_NAME || ''.'' || NEIBTS.BTS_ID || ''.'' || NEISECTOR.SECTOR_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2015, null, '������������', 'replace(NEIADM.COUNTY_NAME, ''��'', '''')', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2016, null, '����������MSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME when ''ZY0810'' then NEIMSC.MSCNAME when ''ZY0804'' then NEIMSC.MSCNAME end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2017, null, '����������MGW��ʶ', null, 'ZY0804', null, '2', null, null, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2018, null, '����������BSC��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME when ''ZY0804'' then NEIMSC.BSCNAME end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2019, null, '����������BTS��ʶ', 'CASE NEIBSC.vendor when ''ZY0808'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0810'' then NEIMSC.MSCNAME || ''.'' || NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID when ''ZY0804'' then NEIMSC.BSCNAME || ''.'' || NEIBTS.BTS_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2020, null, '���������', 'case NEIBSC.vendor when ''ZY0808'' then NEISECTOR.SECTOR_ID when ''ZY0804'' then NEISECTOR.SECTOR_ID when ''ZY0810'' then NEISECTOR.SECTOR_ID end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (2021, null, '����������', 'case NEIBSC.vendor when ''ZY0808'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0804'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') when ''ZY0810'' then replace(NEISECTOR.CHINA_NAME, '','', ''��'') end', 'ZY0804', null, '2', null, 1, 13);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3005, null, 'Դ��������MSC��ʶ', 'CASE orimap.vendor when ''ZY0808'' then MSC.MSCNAME when ''ZY0810'' then MSC.MSCNAME when ''ZY0804'' then MSC.MSCNAME end', 'ZY0808', null, '2', 'SF', 1, 14);
insert into CFG_PROVICE_PERF (ID, LOGICEXPRESS, CHIAN_NAME, EN_NAME, VENDOR, CITY_ID, CLASSCODE, CLASSNAME, ISUSER, DATATYPE)
values (3006, null, 'Դ��������MGW��ʶ', null, 'ZY0808', null, '2', 'SF', null, 14);
commit;
