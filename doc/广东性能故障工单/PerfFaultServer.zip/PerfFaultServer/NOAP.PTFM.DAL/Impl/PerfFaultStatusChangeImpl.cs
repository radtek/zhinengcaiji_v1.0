﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Common;
using NOAP.PTFM.Model;
using System.Data;

namespace NOAP.PTFM.DAL
{
    public class PerfFaultStatusChangeImpl : IPerfFaultStatusChange
    {
        #region IPerfFaultStatusChange 成员

        public string UpdateState(PscParaModel pscpm)
        {
            string selectsql = "select order_state from mod_perftaskmanage where eoms_fault_code='{0}'";
            selectsql = string.Format(selectsql, pscpm.FaultCode);
            try
            {
                DataTable dt = ServiceLocator.DataService.GetDataTable(selectsql);
                if (dt.Rows.Count == 1)
                {
                    if (dt.Rows[0][0].ToString() == "结单")
                    {
                        return "22";
                    }
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            string updatesql = "update mod_perftaskmanage set order_state='{0}', update_time=to_date('{1}','yyyy-mm-dd hh24:mi:ss') where eoms_fault_code='{2}'";
            string insertsql = "insert into mod_perftaskmanage_log(Eoms_Fault_Code,Update_Time,Order_State,Content) values('{0}',to_date('{1}','yyyy-mm-dd hh24:mi:ss'),'{2}','{3}')";

            updatesql = string.Format(updatesql, GetOrderState(pscpm.IType), pscpm.ReplyTime, pscpm.FaultCode);
            insertsql = string.Format(insertsql, pscpm.FaultCode, pscpm.ReplyTime, GetOrderState(pscpm.IType), pscpm.Content);

            try
            {

                int updatenum = ServiceLocator.DataService.ExecNonQuery(updatesql);
                if (updatenum == 1)
                {
                    int insertnum = ServiceLocator.DataService.ExecNonQuery(insertsql);
                    return "11";
                }
                else
                {
                    return "00";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private string GetOrderState(string num)
        {
            string state = string.Empty;
            switch (num)
            {
                case "1":
                    state = "评估";
                    break;
                case "2":
                    state = "强制结单";
                    break;
                case "3":
                    state = "挂起";
                    break;
                case "4":
                    state = "解挂";
                    break;
                default:
                    state = num;
                    break;
            }
            return state;
        }

        #endregion
    }
}
