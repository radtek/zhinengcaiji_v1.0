﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using NOAP.PTFM.Common;
using NOAP.PTFM.Model;

namespace NOAP.PTFM.DAL
{
    public class PerfFaultConfirmImpl : IPerfFaultConfirm
    {
        #region IPerfFaultConfirm 成员

        public List<PfcParaModel> GetConfirmOrder(int cityid, int modelid)
        {
            List<PfcParaModel> listcpm = new List<PfcParaModel>();
            DataTable table = null;
            string sql = @"select eoms_fault_code,order_state,shelf_life from mod_perftaskmanage where order_state='评估' and shelf_life<0 and city_id=" + cityid + " and send_model_id=" + modelid;
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table != null)
            {
                int count = table.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        PfcParaModel cpm = new PfcParaModel();
                        cpm.FaultCode = row[0].ToString().Trim();
                        if ( Convert.ToInt32(row[2]) == -1)
                        {
                            cpm.IsRecovery = 1;
                            cpm.Recovery = "故障恢复";
                        }
                        else
                        {
                            cpm.IsRecovery = 2;
                            cpm.Recovery = "故障未恢复";
                        }
                        cpm.ConfirmTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        listcpm.Add(cpm);
                    }
                }
            }
            return listcpm;
        }

        public bool UpdateState(PfcParaModel pscpm, PfcReturnModel retpsc)
        {
            string updatesql = "update mod_perftaskmanage set order_state='{0}',mark={1},update_time=to_date('{2}','yyyy-mm-dd hh24:mi:ss'),shelf_life=0 where eoms_fault_code='{3}'";
            string insertsql = "insert into mod_perftaskmanage_log(Eoms_Fault_Code,Update_Time,Order_State,Content) values('{0}',to_date('{1}','yyyy-mm-dd hh24:mi:ss'),'{2}','{3}')";

            if (retpsc.IsSuccess == 1)
            {
                if (pscpm.IsRecovery == 1)
                {
                    updatesql = string.Format(updatesql, "结单", "0", pscpm.ConfirmTime, pscpm.FaultCode);
                    insertsql = string.Format(insertsql, pscpm.FaultCode, pscpm.ConfirmTime, "结单", pscpm.Recovery);
                }
                else
                {
                    updatesql = string.Format(updatesql, "处理中", "3", pscpm.ConfirmTime, pscpm.FaultCode);
                    insertsql = string.Format(insertsql, pscpm.FaultCode, pscpm.ConfirmTime, "处理中", pscpm.Recovery);
                }
                try
                {
                    ServiceLocator.DataService.ExecNonQuery(updatesql);
                    ServiceLocator.DataService.ExecNonQuery(insertsql);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            else
             {
                insertsql = string.Format(insertsql, pscpm.FaultCode, pscpm.ConfirmTime, "通知失败", "调用EOMS故障恢复通知接口失败。");
                ServiceLocator.DataService.ExecNonQuery(insertsql);
                return false;
            }
        }

        #endregion
    }
}
