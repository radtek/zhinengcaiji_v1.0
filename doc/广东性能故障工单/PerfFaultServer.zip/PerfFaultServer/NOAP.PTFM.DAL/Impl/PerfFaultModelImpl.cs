﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;
using System.Data;
using NOAP.PTFM.Common;

namespace NOAP.PTFM.DAL
{
    public class PerfFaultModelImpl : IPerfFaultModel
    {
        List<HourPerfFaultModel> IPerfFaultModel.GetHourPerfFaultModel()
        {
            List<HourPerfFaultModel> listHPFM = new List<HourPerfFaultModel>();
            DataTable table = null;
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from mod_perftaskfaultmodel_hour t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table != null)
            {
                int count = table.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        HourPerfFaultModel hourPFM = new HourPerfFaultModel();
                        hourPFM.ModelID = Convert.ToInt32(row["model_id"]);
                        hourPFM.ModelName = row["model_name"].ToString().Trim();
                        hourPFM.CityID = Convert.ToInt32(row["city_id"]);
                        hourPFM.Vendor = row["vendor"].ToString().Trim();
                        hourPFM.NeLevel = row["ne_level"].ToString().Trim();
                        hourPFM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        hourPFM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        hourPFM.IsValid = row["is_valid"].ToString().Trim();
                        listHPFM.Add(hourPFM);
                    }
                }
            }
            return listHPFM;
        }

        private List<SqlPerfFaultModel> GetSqlString(int city_id, int sqlmodelid)
        {
            //获取sql语句
            List<SqlPerfFaultModel> listsql = new List<SqlPerfFaultModel>();
            string strsql = @"select t.model_id,t.func_depict,t.func_sql,t.seqno from mod_perffaultmodel_sql t where t.model_id={0} order by t.seqno";
            DataTable sqldt = ServiceLocator.DataService.GetDataTable(string.Format(strsql, sqlmodelid));

            //获取sql的参数
            string strpara = @"with myPara as (select model_id,sql_seqno, para_seqno,wmsys.wm_concat(para_value)over(partition by model_id,sql_seqno order by para_seqno) allpara
                            from mod_perffaultmodel_config where city_id={0} and model_id={1}) select allpara from myPara a where not exists
                            (select 1 from myPara b where a.model_id=b.model_id and a.sql_seqno=b.sql_seqno and a.para_seqno<b.para_seqno) order by sql_seqno";
            DataTable paradt = ServiceLocator.DataService.GetDataTable(string.Format(strpara, city_id, sqlmodelid));

            if (sqldt != null)
            {
                int count = sqldt.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow sqlrow = sqldt.Rows[i];
                        DataRow pararow = paradt.Rows[i];
                        SqlPerfFaultModel sql = new SqlPerfFaultModel();
                        sql.ModelID = Convert.ToInt32(sqlrow["model_id"]);
                        sql.FuncDepict = sqlrow["func_depict"].ToString();
                        sql.FuncSql = string.Format(sqlrow["func_sql"].ToString(), (Object[])pararow[0].ToString().Split(','));
                        sql.Seqno = Convert.ToInt32(sqlrow["seqno"]);
                        listsql.Add(sql);
                    }
                }
            }
            return listsql;

        }

        List<DayPerfFaultModel> IPerfFaultModel.GetDayPerfFaultModel()
        {
            List<DayPerfFaultModel> listPFM = new List<DayPerfFaultModel>();
            DataTable table = new DataTable();
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from mod_perftaskfaultmodel_day t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table.Columns.Count > 0)
            {
                int count = table.Rows.Count;
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        DayPerfFaultModel dayPFM = new DayPerfFaultModel();
                        dayPFM.ModelID = Convert.ToInt32(row["model_id"]);
                        dayPFM.ModelName = row["model_name"].ToString().Trim();
                        dayPFM.CityID = Convert.ToInt32(row["city_id"]);
                        dayPFM.Vendor = row["vendor"].ToString().Trim();
                        dayPFM.NeLevel = row["ne_level"].ToString().Trim();
                        dayPFM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        dayPFM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        dayPFM.IsValid = row["is_valid"].ToString().Trim();
                        listPFM.Add(dayPFM);
                    }
                }
            }
            return listPFM;
        }

        List<WeekPerfFaultModel> IPerfFaultModel.GetWeekPerfFaultModel()
        {
            List<WeekPerfFaultModel> listPFM = new List<WeekPerfFaultModel>();
            DataTable table = new DataTable();
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from MOD_PERFTASKFAULTMODEL_WEEK t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table.Columns.Count > 0)
            {
                int count = table.Rows.Count;
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        WeekPerfFaultModel dayPFM = new WeekPerfFaultModel();
                        dayPFM.ModelID = Convert.ToInt32(row["model_id"]);
                        dayPFM.ModelName = row["model_name"].ToString().Trim();
                        dayPFM.CityID = Convert.ToInt32(row["city_id"]);
                        dayPFM.Vendor = row["vendor"].ToString().Trim();
                        dayPFM.NeLevel = row["ne_level"].ToString().Trim();
                        dayPFM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        dayPFM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        dayPFM.IsValid = row["is_valid"].ToString().Trim();
                        listPFM.Add(dayPFM);
                    }
                }
            }
            return listPFM;
        }

        int IPerfFaultModel.ExceSql(string ifsql)
        {
            return ServiceLocator.DataService.ExecNonQuery(ifsql);
        }

        List<DayPerfSendModel> IPerfFaultModel.GetDayPerfSendModel()
        {
            List<DayPerfSendModel> listPFM = new List<DayPerfSendModel>();
            DataTable table = null;
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from mod_perftasksendmodel_day t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table != null)
            {
                int count = table.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        DayPerfSendModel dayPFM = new DayPerfSendModel();
                        dayPFM.ModelID = Convert.ToInt32(row["model_id"]);
                        dayPFM.ModelName = row["model_name"].ToString().Trim();
                        dayPFM.CityID = Convert.ToInt32(row["city_id"]);
                        dayPFM.Vendor = row["vendor"].ToString().Trim();
                        dayPFM.NeLevel = row["ne_level"].ToString().Trim();
                        dayPFM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        dayPFM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        dayPFM.IsValid = row["is_valid"].ToString().Trim();
                        listPFM.Add(dayPFM);
                    }
                }
            }
            return listPFM;
        }

        List<WeekPerfSendModel> IPerfFaultModel.GetWeekPerfSendModel()
        {
            List<WeekPerfSendModel> listPFM = new List<WeekPerfSendModel>();
            DataTable table = null;
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from MOD_PERFTASKSENDMODEL_WEEK t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table != null)
            {
                int count = table.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        WeekPerfSendModel dayPFM = new WeekPerfSendModel();
                        dayPFM.ModelID = Convert.ToInt32(row["model_id"]);
                        dayPFM.ModelName = row["model_name"].ToString().Trim();
                        dayPFM.CityID = Convert.ToInt32(row["city_id"]);
                        dayPFM.Vendor = row["vendor"].ToString().Trim();
                        dayPFM.NeLevel = row["ne_level"].ToString().Trim();
                        dayPFM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        dayPFM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        dayPFM.IsValid = row["is_valid"].ToString().Trim();
                        listPFM.Add(dayPFM);
                    }
                }
            }
            return listPFM;
        }


        List<PerfNeStateModel> IPerfFaultModel.GetPerfNeStateModel()
        {
            List<PerfNeStateModel> listPNS = new List<PerfNeStateModel>();
            DataTable table = null;
            string sql = "select t.model_id,t.model_name,t.city_id,t.vendor,t.ne_level,t.sql_model_id,t.is_sys_conf,t.is_valid from mod_perfnestate_model t where t.is_valid = 1";
            table = ServiceLocator.DataService.GetDataTable(sql);
            if (table != null)
            {
                int count = table.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = table.Rows[i];
                        PerfNeStateModel perfNSM = new PerfNeStateModel();
                        perfNSM.ModelID = Convert.ToInt32(row["model_id"]);
                        perfNSM.ModelName = row["model_name"].ToString().Trim();
                        perfNSM.CityID = Convert.ToInt32(row["city_id"]);
                        perfNSM.Vendor = row["vendor"].ToString().Trim();
                        perfNSM.NeLevel = row["ne_level"].ToString().Trim();
                        perfNSM.IfSql = GetSqlString(Convert.ToInt32(row["city_id"]), Convert.ToInt32(row["sql_model_id"]));
                        perfNSM.IsSysConf = row["is_sys_conf"].ToString().Trim();
                        perfNSM.IsValid = row["is_valid"].ToString().Trim();
                        listPNS.Add(perfNSM);
                    }
                }
            }
            return listPNS;
        }

        public DataTable GetFailureOrder(int num)
        {
            DataTable table = null;
            string orderidsql = "select order_id from mod_perftaskmanage where order_state='派单失败' and shelf_life>=0 and shelf_life<={0}";
            table = ServiceLocator.DataService.GetDataTable(string.Format(orderidsql, num.ToString()));
            return table;
        }

        public void UpdateFailureOrder(int num)
        {
            string updateordersql = "update mod_perftaskmanage set is_send=0,mark=4,order_state='不派' where order_state='派单失败' and shelf_life>={0}";
            ServiceLocator.DataService.ExecNonQuery(string.Format(updateordersql, num.ToString()));
        }
    }
}
