﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;
using NOAP.PTFM.Common;
using System.Data;

namespace NOAP.PTFM.DAL
{
    public class PerfFaultSendImpl : IPerfFaultSend
    {

        #region IPerfFaultSend 成员

        public PfsParaModel GetComplaintPara(string orderid)
        {
            string where = @"where Order_ID ='{0}'";
            PfsParaModel pfspm = GetOrderInfo(string.Format(where, orderid))[0];
            return pfspm;
        }

        public List<PfsParaModel> GetComplaintPara(int cityid, int modelid)
        {
            string where = @"where city_id={0} and Send_Model_Id={1} and is_send=1 and order_state='待派'";
            List<PfsParaModel> listpfspm = GetOrderInfo(string.Format(where, cityid, modelid));
            return listpfspm;
        }

        private List<PfsParaModel> GetOrderInfo(string strwhere)
        {
            DataTable dt = null;
            string strsend = @"select Order_ID,Start_Time,City_ID,Fault_Type,Ne_Level,Ne_Rank,ne_related,Ne_Name,Period_Level,Fault_Time,Fault_Rank,
                                Fault_Depict,Process_Time_Limit,Send_Name,Send_Model_Id,BSC_ID,BTS_ID,CELL_ID,CARR_ID,SECTOR_ID,FAULT_CATEGORY,FAULT_ALL_TYPE,FAULT_MODEL_NAME from mod_PerfTaskManage {0}";
            dt = ServiceLocator.DataService.GetDataTable(string.Format(strsend, strwhere));
            List<PfsParaModel> listppm = new List<PfsParaModel>();
            if (dt != null)
            {
                int count = dt.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = dt.Rows[i];
                        PfsParaModel ppm = new PfsParaModel();
                        ppm.OutSystemNo = row["ORDER_ID"].ToString().Trim();
                        ppm.SysProbCauseId = row["SEND_MODEL_ID"].ToString();
                        string[] listcity = GetCityInfo(Convert.ToInt32(row["CITY_ID"]));
                        ppm.CptDomainId = listcity[0];
                        ppm.CptDomainName = listcity[1];
                        ppm.NeType = row["NE_LEVEL"].ToString();
                        ppm.NeLevel = row["NE_RANK"].ToString();
                        ppm.PeriodLevel = row["PERIOD_LEVEL"].ToString();
                        if (!string.IsNullOrEmpty(row["BSC_ID"].ToString()))
                        {
                            ppm.BscNo = Convert.ToInt32(row["BSC_ID"]);
                        }
                        if (!string.IsNullOrEmpty(row["BTS_ID"].ToString()))
                        {
                            ppm.BtsNo = Convert.ToInt32(row["BTS_ID"]);
                        }
                        if (!string.IsNullOrEmpty(row["CELL_ID"].ToString()))
                        {
                            ppm.CellNo = Convert.ToInt32(row["CELL_ID"]);
                        }
                        if (!string.IsNullOrEmpty(row["SECTOR_ID"].ToString()))
                        {
                            ppm.SectorNo = Convert.ToInt32(row["SECTOR_ID"]);
                        }
                        if (!string.IsNullOrEmpty(row["CARR_ID"].ToString()))
                        {
                            ppm.CarrNo = Convert.ToInt32(row["CARR_ID"]);
                        }
                        ppm.StationName = row["NE_NAME"].ToString();
                        ppm.StationAddr = row["NE_NAME"].ToString();
                        ppm.OccurNum = 1;
                        ppm.FaultStartTime = row["FAULT_TIME"].ToString().Substring(0,10) + " 00:00:00";
                        ppm.AlarmLevel = row["FAULT_RANK"].ToString();
                        ppm.AlarmTime = "24小时";
                        ppm.ProcessTimeLimit = Convert.ToInt32(row["PROCESS_TIME_LIMIT"])*60;
                        ppm.AlarmPos = row["NE_NAME"].ToString(); 
                        ppm.PreProcDetail = "";
                        ppm.AlarmContent = row["FAULT_DEPICT"].ToString();
                        ppm.FaultReason = "";
                        ppm.FaultCategory = row["FAULT_CATEGORY"].ToString();
                        ppm.FaultType = row["FAULT_ALL_TYPE"].ToString() + "-" + row["FAULT_TYPE"].ToString() + "-" + row["FAULT_MODEL_NAME"].ToString();
                        ppm.FaultAssigned = 1;
                        listppm.Add(ppm);
                    }
                }
            }
            return listppm;
        }

        private string[] GetCityInfo(int cityid)
        {
            string[] cityinfo = new string[2];
            switch (cityid)
            {
                case 20:
                    cityinfo[0] = "1020002";
                    cityinfo[1] = "广州";
                    break;
                case 755:
                    cityinfo[0] = "1010001";
                    cityinfo[1] = "深圳";
                    break;
                case 769:
                    cityinfo[0] = "1040008";
                    cityinfo[1] = "东莞";
                    break;
                case 757:
                    cityinfo[0] = "1050011";
                    cityinfo[1] = "佛山";
                    break;
                case 760:
                    cityinfo[0] = "1030006";
                    cityinfo[1] = "中山";
                    break;
                case 752:
                    cityinfo[0] = "1040009";
                    cityinfo[1] = "惠州";
                    break;
                case 750:
                    cityinfo[0] = "1030007";
                    cityinfo[1] = "江门";
                    break;
                case 756:
                    cityinfo[0] = "1030022";
                    cityinfo[1] = "珠海";
                    break;
                case 754:
                    cityinfo[0] = "1060019";
                    cityinfo[1] = "汕头";
                    break;
                case 663:
                    cityinfo[0] = "1060018";
                    cityinfo[1] = "揭阳";
                    break;
                case 768:
                    cityinfo[0] = "1060020";
                    cityinfo[1] = "潮州";
                    break;
                case 660:
                    cityinfo[0] = "1060017";
                    cityinfo[1] = "汕尾";
                    break;
                case 759:
                    cityinfo[0] = "1050016";
                    cityinfo[1] = "湛江";
                    break;
                case 668:
                    cityinfo[0] = "1050014";
                    cityinfo[1] = "茂名";
                    break;
                case 662:
                    cityinfo[0] = "1050015";
                    cityinfo[1] = "阳江";
                    break;
                case 766:
                    cityinfo[0] = "1050013";
                    cityinfo[1] = "云浮";
                    break;
                case 758:
                    cityinfo[0] = "1050012";
                    cityinfo[1] = "肇庆";
                    break;
                case 753:
                    cityinfo[0] = "1060021";
                    cityinfo[1] = "梅州";
                    break;
                case 763:
                    cityinfo[0] = "1020003";
                    cityinfo[1] = "清远";
                    break;
                case 762:
                    cityinfo[0] = "1040010";
                    cityinfo[1] = "河源";
                    break;
                case 751:
                    cityinfo[0] = "1020004";
                    cityinfo[1] = "韶关";
                    break;
                default:
                    break;
            }
            return cityinfo;
        }

        public bool UpdateOrderManage(string orderid, PfsReturnModel rpm)
        {
            string updatesql = "update mod_perftaskmanage set order_state='{0}',mark={1},update_time=to_date('{2}','yyyy-mm-dd hh24:mi:ss'),eoms_fault_code='{3}',shelf_life={4} where order_id='{5}'";
            string insertsql = "insert into mod_perftaskmanage_log(Eoms_Fault_Code,Update_Time,Order_State,Content) values('{0}',to_date('{1}','yyyy-mm-dd hh24:mi:ss'),'{2}','{3}')";

            if (rpm.IsSuccess == 1)
            {
                updatesql = string.Format(updatesql, "处理中", "2", rpm.CreateTime, rpm.FaultCode, "0", orderid);
                insertsql = string.Format(insertsql, rpm.FaultCode, rpm.CreateTime, "处理中", rpm.ResultDesc); 
               
            }
            else
            {
                updatesql = string.Format(updatesql, "派单失败", "1", rpm.CreateTime, rpm.FaultCode, "shelf_life+1", orderid);
                insertsql = string.Format(insertsql, orderid, rpm.CreateTime, "派单失败", rpm.ResultDesc);
            }
            try
            {
                ServiceLocator.DataService.ExecNonQuery(updatesql);
                ServiceLocator.DataService.ExecNonQuery(insertsql);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion

        #region IPerfFaultSend 成员


        public bool UpdateUserSendOrder(string orderid, string modelid)
        {
            string strupdate = @"update mod_perftaskmanage t set t.is_send=0,t.mark=3,order_state='不派',update_time=sysdate 
                                where t.send_model_id={0} and order_state='待派' and t.ne_related = 
                                (select ne_related from mod_perftaskmanage where order_id='{1}')";
            try
            {
                ServiceLocator.DataService.ExecNonQuery(string.Format(strupdate, modelid, orderid));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion
    }
}
