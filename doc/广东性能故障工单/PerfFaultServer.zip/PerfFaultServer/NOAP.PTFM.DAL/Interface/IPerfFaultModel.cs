﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;
using System.Data;

namespace NOAP.PTFM.DAL
{
    public interface IPerfFaultModel
    {
        /// <summary>
        /// 获取小时工单模型
        /// </summary>
        /// <returns></returns>
        List<HourPerfFaultModel> GetHourPerfFaultModel();

        /// <summary>
        /// 获取天工单模型
        /// </summary>
        /// <returns></returns>
        List<DayPerfFaultModel> GetDayPerfFaultModel();

        /// <summary>
        /// 获取周工单模型
        /// </summary>
        /// <returns></returns>
        List<WeekPerfFaultModel> GetWeekPerfFaultModel();

        /// <summary>
        /// 获取天派单模型
        /// </summary>
        /// <returns></returns>
        List<DayPerfSendModel> GetDayPerfSendModel();

        /// <summary>
        /// 获取周派单模型
        /// </summary>
        /// <returns></returns>
        List<WeekPerfSendModel> GetWeekPerfSendModel();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ifsql"></param>
        /// <returns></returns>
        int ExceSql(string ifsql);

        List<PerfNeStateModel> GetPerfNeStateModel();


        DataTable GetFailureOrder(int num);

        void UpdateFailureOrder(int num);
    }
}
