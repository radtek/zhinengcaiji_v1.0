﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;

namespace NOAP.PTFM.DAL
{
    public interface IPerfFaultStatusChange
    {
        string UpdateState(PscParaModel pscpm);
    }
}
