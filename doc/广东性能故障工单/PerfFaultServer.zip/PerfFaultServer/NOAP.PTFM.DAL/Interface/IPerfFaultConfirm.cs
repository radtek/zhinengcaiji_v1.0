﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;

namespace NOAP.PTFM.DAL
{
    public interface IPerfFaultConfirm
    {
        List<PfcParaModel> GetConfirmOrder(int cityid, int modelid);

        bool UpdateState(PfcParaModel pscpm, PfcReturnModel retpsc);
    }
}
