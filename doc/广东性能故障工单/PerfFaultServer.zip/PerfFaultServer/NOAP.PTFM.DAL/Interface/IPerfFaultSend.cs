﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;

namespace NOAP.PTFM.DAL
{
    public interface IPerfFaultSend
    {
        PfsParaModel GetComplaintPara(string orderid);

        List<PfsParaModel> GetComplaintPara(int cityid, int modelid);

        bool UpdateOrderManage(string orderid, PfsReturnModel rpm);

        bool UpdateUserSendOrder(string orderid, string modelid);
    }
}
