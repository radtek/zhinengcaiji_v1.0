﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Auth")] 
    public class AuthModel
    {
        private int _FlowId = 1;
        [XmlElement("flowId")]
        public int FlowId
        {
            get { return _FlowId; }
            set { _FlowId = value; }
        }

        private string _FlowName = "网优性能故障";
        [XmlElement("flowName")]
        public string FlowName
        {
            get { return _FlowName; }
            set { _FlowName = value; }
        }

        private string _AuthKey;
        [XmlElement("authKey")]
        public string AuthKey
        {
            get { return _AuthKey; }
            set { _AuthKey = value; }
        }

        private string _SystemId = "网优平台";
        [XmlElement("systemId")]
        public string SystemId
        {
            get { return _SystemId; }
            set { _SystemId = value; }
        }

        private int _Mode = 1;
        [XmlElement("mode")]
        public int Mode
        {
            get { return _Mode; }
            set { _Mode = value; }
        }

        private int _BillType = 1;
        [XmlElement("BillType")]
        public int BillType
        {
            get { return _BillType; }
            set { _BillType = value; }
        }
    }
}
