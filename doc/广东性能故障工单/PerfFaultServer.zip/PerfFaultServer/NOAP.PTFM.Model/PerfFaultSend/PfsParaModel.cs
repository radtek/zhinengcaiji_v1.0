﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Data")]
    public class PfsParaModel
    {
        /// <summary>
        /// 故障单（母单）受理部门ID
        /// </summary>
        private string _AcceptDeptId = "1500038500";
        [XmlElement("acceptDeptId")]
        public string AcceptDeptId
        {
            get { return _AcceptDeptId; }
            set { _AcceptDeptId = value; }
        }

        /// <summary>
        /// 故障单（母单）受理部门所在区域ID
        /// </summary>
        private string _DomainId = "1010002";
        [XmlElement("domainId")]
        public string DomainId
        {
            get { return _DomainId; }
            set { _DomainId = value; }
        }

        /// <summary>
        /// 网优平台的“故障单号”
        /// </summary>
        private string _OutSystemNo;
        [XmlElement("outSystemNo")]
        public string OutSystemNo
        {
            get { return _OutSystemNo; }
            set { _OutSystemNo = value; }
        }

        /// <summary>
        /// 网优平台中的“告警码”
        /// </summary>
        private string _SysProbCauseId;
        [XmlElement("sysProbCauseId")]
        public string SysProbCauseId
        {
            get { return _SysProbCauseId; }
            set { _SysProbCauseId = value; }
        }

        /// <summary>
        /// 地市标识
        /// </summary>
        private string _CptDomainId;
        [XmlElement("cptDomainId")]
        public string CptDomainId
        {
            get { return _CptDomainId; }
            set { _CptDomainId = value; }
        }

        /// <summary>
        /// 地市名称
        /// </summary>
        private string _CptDomainName;
        [XmlElement("cptDomainName")]
        public string CptDomainName
        {
            get { return _CptDomainName; }
            set { _CptDomainName = value; }
        }

        /// <summary>
        /// 网元类型
        /// </summary>
        private string _NeType;
        [XmlElement("neType")]
        public string NeType
        {
            get { return _NeType; }
            set { _NeType = value; }
        }

        /// <summary>
        /// 网元级别
        /// </summary>
        private string _NeLevel;
        [XmlElement("neLevel")]
        public string NeLevel
        {
            get { return _NeLevel; }
            set { _NeLevel = value; }
        }

        /// <summary>
        /// 周期级别
        /// </summary>
        private string _PeriodLevel;
        [XmlElement("periodLevel")]
        public string PeriodLevel
        {
            get { return _PeriodLevel; }
            set { _PeriodLevel = value; }
        }

        /// <summary>
        /// BSC编号
        /// </summary>
        private int _BscNo;
        [XmlElement("bscNo")]
        public int BscNo
        {
            get { return _BscNo; }
            set { _BscNo = value; }
        }

        /// <summary>
        /// BTS编号
        /// </summary>
        private int _BtsNo;
        [XmlElement("btsNo")]
        public int BtsNo
        {
            get { return _BtsNo; }
            set { _BtsNo = value; }
        }

        /// <summary>
        /// CELL编号
        /// </summary>
        private int _CellNo;
        [XmlElement("cellNo")]
        public int CellNo
        {
            get { return _CellNo; }
            set { _CellNo = value; }
        }

        /// <summary>
        /// SectorNo
        /// </summary>
        private int _SectorNo;
        [XmlElement("sectorNo")]
        public int SectorNo
        {
            get { return _SectorNo; }
            set { _SectorNo = value; }
        }

        /// <summary>
        /// 载频编号
        /// </summary>
        private int _CarrNo;
        [XmlElement("carrNo")]
        public int CarrNo
        {
            get { return _CarrNo; }
            set { _CarrNo = value; }
        }

        /// <summary>
        /// 基站名称
        /// </summary>
        private string _StationName;
        [XmlElement("stationName")]
        public string StationName
        {
            get { return _StationName; }
            set { _StationName = value; }
        }

        /// <summary>
        /// 基站地址
        /// </summary>
        private string _StationAddr;
        [XmlElement("stationAddr")]
        public string StationAddr
        {
            get { return _StationAddr; }
            set { _StationAddr = value; }
        }

        /// <summary>
        /// 故障发生次数
        /// </summary>
        private int _OccurNum = 1;
        [XmlElement("occurNum")]
        public int OccurNum
        {
            get { return _OccurNum; }
            set { _OccurNum = value; }
        }

        /// <summary>
        /// 告警发生时间
        /// </summary>
        private string _FaultStartTime;
        [XmlElement("faultStartTime")]
        public string FaultStartTime
        {
            get { return _FaultStartTime; }
            set { _FaultStartTime = value; }
        }

        /// <summary>
        /// 告警级别
        /// </summary>
        private string _AlarmLevel;
        [XmlElement("alarmLevel")]
        public string AlarmLevel
        {
            get { return _AlarmLevel; }
            set { _AlarmLevel = value; }
        }

        /// <summary>
        /// 告警时长
        /// </summary>
        private string _AlarmTime;
        [XmlElement("alarmTime")]
        public string AlarmTime
        {
            get { return _AlarmTime; }
            set { _AlarmTime = value; }
        }

        /// <summary>
        /// 处理时限
        /// </summary>
        private int _ProcessTimeLimit;
        [XmlElement("processTimeLimit")]
        public int ProcessTimeLimit
        {
            get { return _ProcessTimeLimit; }
            set { _ProcessTimeLimit = value; }
        }

        /// <summary>
        /// 故障位置
        /// </summary>
        private string _AlarmPos;
        [XmlElement("alarmPos")]
        public string AlarmPos
        {
            get { return _AlarmPos; }
            set { _AlarmPos = value; }
        }

        /// <summary>
        /// 预处理
        /// </summary>
        private string _PreProcDetail;
        [XmlElement("preProcDetail")]
        public string PreProcDetail
        {
            get { return _PreProcDetail; }
            set { _PreProcDetail = value; }
        }

        /// <summary>
        /// 故障内容
        /// </summary>
        private string _AlarmContent;
        [XmlElement("alarmContent")]
        public string AlarmContent
        {
            get { return _AlarmContent; }
            set { _AlarmContent = value; }
        }

        /// <summary>
        /// 故障原因
        /// </summary>
        private string _FaultReason;
        [XmlElement("faultReason")]
        public string FaultReason
        {
            get { return _FaultReason; }
            set { _FaultReason = value; }
        }

        /// <summary>
        /// 是否由接口报障
        /// </summary>
        private string _IsInterface = "1";
        [XmlElement("isInterface")]
        public string IsInterface
        {
            get { return _IsInterface; }
            set { _IsInterface = value; }
        }

        /// <summary>
        /// 是否自动派单
        /// </summary>
        private int _IsAuto = 1;
        [XmlElement("isAuto")]
        public int IsAuto
        {
            get { return _IsAuto; }
            set { _IsAuto = value; }
        }

        /// <summary>
        /// 系统标识
        /// </summary>
        private int _Source = 39;
        [XmlElement("source")]
        public int Source
        {
            get { return _Source; }
            set { _Source = value; }
        }

        /// <summary>
        /// 故障种类
        /// </summary>
        private string _FaultCategory;
        [XmlElement("faultCategory")]
        public string FaultCategory
        {
            get { return _FaultCategory; }
            set { _FaultCategory = value; }
        }

        /// <summary>
        /// 故障类型
        /// </summary>
        private string _FaultType;
        [XmlElement("faultType")]
        public string FaultType
        {
            get { return _FaultType; }
            set { _FaultType = value; }
        }

        /// <summary>
        /// 故障指配
        /// </summary>
        private int _FaultAssigned = 1;
        [XmlElement("faultAssigned")]
        public int FaultAssigned
        {
            get { return _FaultAssigned; }
            set { _FaultAssigned = value; }
        }
    }
}
