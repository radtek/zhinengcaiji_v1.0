﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Service")]
    public class ComplaintModel
    {
        private AuthModel _Auth;
        [XmlElement("Auth")]
        public AuthModel Auth
        {
            get { return _Auth; }
            set { _Auth = value; }
        }

        private PfsParaModel _Para;
        [XmlElement("Data")]
        public PfsParaModel Para
        {
            get { return _Para; }
            set { _Para = value; }
        }
    }
}
