﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Service")]
    public class StatusChangeModel
    {

        private AuthModel _Auth;
        [XmlElement("Auth")]
        public AuthModel Auth
        {
            get { return _Auth; }
            set { _Auth = value; }
        }

        private PscParaModel _Para;
        [XmlElement("Data")]
        public PscParaModel Para
        {
            get { return _Para; }
            set { _Para = value; }
        }
    }
}
