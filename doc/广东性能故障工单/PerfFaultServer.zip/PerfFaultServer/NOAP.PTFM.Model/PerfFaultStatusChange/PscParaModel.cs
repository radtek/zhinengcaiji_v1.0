﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Data")]
    public class PscParaModel
    {
        private string _FaultCode;
        [XmlElement("faultCode")]
        public string FaultCode
        {
            get { return _FaultCode; }
            set { _FaultCode = value; }
        }

        private string _IType;
        [XmlElement("type")]
        public string IType
        {
            get { return _IType; }
            set { _IType = value; }
        }

        private string _ReplyTime;
        [XmlElement("replyTime")]
        public string ReplyTime
        {
            get { return _ReplyTime; }
            set { _ReplyTime = value; }
        }

        private string _Content;
        [XmlElement("SContent")]
        public string Content
        {
            get { return _Content; }
            set { _Content = value; }
        }

        private string _SystemNo;
        [XmlElement("systemNo")]
        public string SystemNo
        {
            get { return _SystemNo; }
            set { _SystemNo = value; }
        }

        private string _RestoreTime;
        [XmlElement("restoreTime")]
        public string RestoreTime
        {
            get { return _RestoreTime; }
            set { _RestoreTime = value; }
        }
    }
}
