﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [XmlRoot("Data")]
    public class PfcParaModel
    {
        private string _FaultCode;
        [XmlElement("faultCode")]
        public string FaultCode
        {
            get { return _FaultCode; }
            set { _FaultCode = value; }
        }

        private int _IsRecovery;
        [XmlElement("iIsRecovery")]
        public int IsRecovery
        {
            get { return _IsRecovery; }
            set { _IsRecovery = value; }
        }

        private string _Recovery;
        [XmlElement("sRecovery")]
        public string Recovery
        {
            get { return _Recovery; }
            set { _Recovery = value; }
        }

        private string _ConfirmTime;
        [XmlElement("dConfirmTime")]
        public string ConfirmTime
        {
            get { return _ConfirmTime; }
            set { _ConfirmTime = value; }
        }
    }
}
