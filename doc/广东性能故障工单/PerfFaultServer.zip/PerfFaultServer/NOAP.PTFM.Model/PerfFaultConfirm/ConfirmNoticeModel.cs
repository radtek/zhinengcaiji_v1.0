﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [Serializable]
    [XmlRoot("Service")]
    public class ConfirmNoticeModel
    {
        private AuthModel _Auth;
        [XmlElement("Auth")]
        public AuthModel Auth
        {
            get { return _Auth; }
            set { _Auth = value; }
        }

        private PfcParaModel _Para;
        [XmlElement("Data")]
        public PfcParaModel Para
        {
            get { return _Para; }
            set { _Para = value; }
        }
    }
}
