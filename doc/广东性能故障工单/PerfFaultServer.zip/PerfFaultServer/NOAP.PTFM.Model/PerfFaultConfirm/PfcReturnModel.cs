﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NOAP.PTFM.Model
{
    [XmlRoot("Service")]
    public class PfcReturnModel
    {
        private string _FaultCode;
        [XmlElement("faultCode")]
        public string FaultCode
        {
            get { return _FaultCode; }
            set { _FaultCode = value; }
        }


        private int _IsSuccess;
        [XmlElement("isSuccess")]
        public int IsSuccess
        {
            get { return _IsSuccess; }
            set { _IsSuccess = value; }
        }

        private string _ResultDesc;
        [XmlElement("resultDesc")]
        public string ResultDesc
        {
            get { return _ResultDesc; }
            set { _ResultDesc = value; }
        }

        private string _CreateTime;
        [XmlElement("dCreateTime")]
        public string CreateTime
        {
            get { return _CreateTime; }
            set { _CreateTime = value; }
        }
    }
}
