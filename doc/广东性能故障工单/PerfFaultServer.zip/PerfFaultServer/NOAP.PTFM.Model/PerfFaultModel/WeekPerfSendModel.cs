﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Model
{
    public class WeekPerfSendModel
    {
        /// <summary>
        /// 模型ID
        /// </summary>
        private int _ModelID;
        public int ModelID
        {
            get { return _ModelID; }
            set { _ModelID = value; }
        }

        /// <summary>
        /// 模型名称
        /// </summary>
        private string _ModelName;
        public string ModelName
        {
            get { return _ModelName; }
            set { _ModelName = value; }
        }

        /// <summary>
        /// 城市ID
        /// </summary>
        private int _CityID;
        public int CityID
        {
            get { return _CityID; }
            set { _CityID = value; }
        }

        /// <summary>
        /// 厂家ID
        /// </summary>
        private string _Vendor;
        public string Vendor
        {
            get { return _Vendor; }
            set { _Vendor = value; }
        }

        /// <summary>
        /// 网元粒度
        /// </summary>
        private string _NeLevel;
        public string NeLevel
        {
            get { return _NeLevel; }
            set { _NeLevel = value; }
        }

        /// <summary>
        /// 跟该模型相关的sql模板列表
        /// </summary>
        private List<SqlPerfFaultModel> _IfSql;
        public List<SqlPerfFaultModel> IfSql
        {
            get { return _IfSql; }
            set { _IfSql = value; }
        }

        /// <summary>
        /// 是否系统设置
        /// </summary>
        private string _IsSysConf;
        public string IsSysConf
        {
            get { return _IsSysConf; }
            set { _IsSysConf = value; }
        }

        /// <summary>
        /// 是否起效
        /// </summary>
        private string _IsValid;
        public string IsValid
        {
            get { return _IsValid; }
            set { _IsValid = value; }
        }
    }
}
