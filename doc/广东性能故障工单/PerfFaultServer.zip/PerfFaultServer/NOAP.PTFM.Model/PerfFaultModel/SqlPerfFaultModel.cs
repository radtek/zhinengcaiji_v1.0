﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Model
{
    /// <summary>
    /// 模型sql模板
    /// </summary>
    public class SqlPerfFaultModel
    {
        /// <summary>
        /// sql模板ID
        /// </summary>
        private int _ModelID;
        public int ModelID
        {
            get { return _ModelID; }
            set { _ModelID = value; }
        }

        /// <summary>
        /// sql语句描述
        /// </summary>
        private string _FuncDepict;
        public string FuncDepict
        {
            get { return _FuncDepict; }
            set { _FuncDepict = value; }
        }

        /// <summary>
        /// sql语句
        /// </summary>
        private string _FuncSql;
        public string FuncSql
        {
            get { return _FuncSql; }
            set { _FuncSql = value; }
        }

        /// <summary>
        /// sql语句编号，执行sql语句需要按照该编号顺序
        /// </summary>
        private int _Seqno;
        public int Seqno
        {
            get { return _Seqno; }
            set { _Seqno = value; }
        }

    }
}
