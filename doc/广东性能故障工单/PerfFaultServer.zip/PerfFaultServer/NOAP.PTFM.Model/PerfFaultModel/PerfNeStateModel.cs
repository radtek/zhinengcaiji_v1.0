﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Model
{
    public class PerfNeStateModel
    {
        private int _ModelID;

        public int ModelID
        {
            get { return _ModelID; }
            set { _ModelID = value; }
        }

        private string _ModelName;

        public string ModelName
        {
            get { return _ModelName; }
            set { _ModelName = value; }
        }

        private int _CityID;

        public int CityID
        {
            get { return _CityID; }
            set { _CityID = value; }
        }

        private string _Vendor;

        public string Vendor
        {
            get { return _Vendor; }
            set { _Vendor = value; }
        }

        private string _NeLevel;

        public string NeLevel
        {
            get { return _NeLevel; }
            set { _NeLevel = value; }
        }

        private List<SqlPerfFaultModel> _IfSql;

        public List<SqlPerfFaultModel> IfSql
        {
            get { return _IfSql; }
            set { _IfSql = value; }
        }

        private string _IsSysConf;

        public string IsSysConf
        {
            get { return _IsSysConf; }
            set { _IsSysConf = value; }
        }

        private string _IsValid;

        public string IsValid
        {
            get { return _IsValid; }
            set { _IsValid = value; }
        }
    }
}
