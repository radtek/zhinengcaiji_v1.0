﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.Common;
using NOAP.CommonDB;
using System.Data;

namespace NOAP.PTFM.Common
{
    public class DataService : IDataService
    {
        public DataService()
        {

            Global.InitConnection();//初始化连接
        }

        #region IDataService 成员

        DataTable IDataService.GetDataTable(string sql)
        {
            return DBAcess.Instance().GetDataTable(sql);
        }

        int IDataService.ExecNonQuery(string sql)
        {
            return DBAcess.Instance().ExecNonQuery(sql);
        }

        #endregion
    }
}
