﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using log4net.Config;

namespace NOAP.PTFM.Common
{
    class LoggingService : ILoggingService
    {
        private ILog log = LogManager.GetLogger("File");

        /// <summary>
        /// 静态构造器，初始化配置监控 
        /// </summary>
        LoggingService()
        {
            //配置Log4net，在应用程序的配置文件中指定一节
            //详见Startup应用的配置文件<configSections有关log4net节>
            //XmlConfigurator.ConfigureAndWatch(new FileInfo("filename"));

            XmlConfigurator.Configure();
        }

        /// <summary>
        /// 调试输出
        /// </summary>
        /// <param name="message"></param>
        public void Debug(object message)
        {
            log.Debug(message);
        }

        /// <summary>
        /// 调试格式化输出
        /// </summary>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void DebugFormatted(string format, params object[] args)
        {
            log.DebugFormat(format, args);
        }

        /// <summary>
        /// 信息输出
        /// </summary>
        /// <param name="message"></param>
        public void Info(object message)
        {
            log.Info(message);
        }

        /// <summary>
        /// 信息格式化输出
        /// </summary>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void InfoFormatted(string format, params object[] args)
        {
            log.InfoFormat(format, args);
        }

        /// <summary>
        /// 警告输出
        /// </summary>
        /// <param name="message"></param>
        public void Warn(object message)
        {
            log.Warn(message);
        }

        /// <summary>
        /// 警告输出
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void Warn(object message, Exception exception)
        {
            log.Warn(message, exception);
        }

        /// <summary>
        /// 警告格式化输出
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WarnFormatted(string format, params object[] args)
        {
            log.WarnFormat(format, args);
        }

        /// <summary>
        /// 错误输出
        /// </summary>
        /// <param name="message"></param>
        public void Error(object message)
        {
            log.Error(message);
        }

        /// <summary>
        /// 错误输出
        /// </summary>
        /// <param name="message"></param>
        public void Error(object message, Exception exception)
        {
            log.Error(message, exception);
        }

        /// <summary>
        /// 错误格式化输出
        /// </summary>
        /// <param name="message"></param>
        public void ErrorFormatted(string format, params object[] args)
        {
            log.ErrorFormat(format, args);
        }

        /// <summary>
        /// 致命错误输出
        /// </summary>
        /// <param name="message"></param>
        public void Fatal(object message)
        {
            log.Fatal(message);
        }

        /// <summary>
        /// 致命错误输出
        /// </summary>
        /// <param name="message"></param>
        public void Fatal(object message, Exception exception)
        {
            log.Fatal(message, exception);
        }

        /// <summary>
        /// 致命错误格式化输出
        /// </summary>
        /// <param name="message"></param>
        public void FatalFormatted(string format, params object[] args)
        {
            log.FatalFormat(format, args);
        }

        /// <summary>
        /// 设置调试输出标志
        /// </summary>
        public bool IsDebugEnabled
        {
            get
            {
                return log.IsDebugEnabled;
            }
        }

        /// <summary>
        /// 设置信息输出标志
        /// </summary>
        public bool IsInfoEnabled
        {
            get
            {
                return log.IsInfoEnabled;
            }
        }

        /// <summary>
        /// 设置警告输出标志
        /// </summary>
        public bool IsWarnEnabled
        {
            get
            {
                return log.IsWarnEnabled;
            }
        }

        /// <summary>
        /// 设置错误输出标志
        /// </summary>
        public bool IsErrorEnabled
        {
            get
            {
                return log.IsErrorEnabled;
            }
        }

        /// <summary>
        /// 设置致命错误输出标志
        /// </summary>
        public bool IsFatalEnabled
        {
            get
            {
                return log.IsFatalEnabled;
            }
        }

    }
}
