﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace NOAP.PTFM.Common
{
    public class RegexService :IRegex
    {
        /// <summary>
        /// 匹配正规表达式
        /// </summary>
        /// <param name="text">要匹配的字符串</param>
        /// <param name="key">正规表达式</param>
        /// <returns>匹配的字符串集</returns>
        public IList<string> Match(string text, string key)
        {
            IList<string> words = new List<string>();

            try
            {
                Regex rx = new Regex(string.Format("(?<word>{0})", key)
                    , RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);

                MatchCollection matches = rx.Matches(text);

                foreach (Match match in matches)
                {
                    words.Add(match.Groups["word"].Value);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return words;
        }

        /// <summary>
        /// 匹配正规表达式
        /// </summary>
        /// <param name="text">要匹配的字符串</param>
        /// <param name="keys">正规表达式集</param>
        /// <returns>匹配的字符串集</returns>
        public IList<string> Match(string text, string[] keys)
        {
            IList<string> words = new List<string>();
            string word;

            try
            {
                Regex[] rxs = new Regex[keys.Length];
                for (int i = 0; i < keys.Length; i++)
                {
                    rxs[i] = new Regex(string.Format("(?<word>{0})", keys[i])
                        , RegexOptions.Compiled | RegexOptions.IgnoreCase);
                }

                MatchCollection matches = rxs[0].Matches(text);

                foreach (Match match in matches)
                {
                    word = match.Groups["word"].Value;
                    for (int i = 1; i < rxs.Length; i++)
                    {
                        word = rxs[i].Match(word).Groups["word"].Value;
                    }
                    words.Add(word);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return words;
        }

        /// <summary>
        /// 是否匹配
        /// </summary>
        /// <param name="text"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool IsMatch(string text, string key)
        {

            bool isMatch = false;

            Regex rx = new Regex(key
                , RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);

            isMatch = rx.IsMatch(text);

            return isMatch;
        }
    }
}
