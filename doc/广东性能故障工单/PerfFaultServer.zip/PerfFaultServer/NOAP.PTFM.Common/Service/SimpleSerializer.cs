﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace NOAP.PTFM.Common
{
    public class SimpleSerializer : ISimpleSerializer
    {
        public SimpleSerializer()
        {

        }

        #region ISimpleSerializer 成员

        string ISimpleSerializer.Serialize<T>(T t)
        {
            using (StringWriter sw = new StringWriter())
            {
                XmlSerializer xz = new XmlSerializer(t.GetType());
                xz.Serialize(sw, t);
                return sw.ToString();
            }
        }

        object ISimpleSerializer.Deserialize(Type type, string s)
        {
            using (StringReader sr = new StringReader(s))
            {
                XmlSerializer xz = new XmlSerializer(type);
                return xz.Deserialize(sr);
            }
        }

        #endregion
    }
}
