﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Common
{
    public class ServiceLocator
    {
        /// <summary>
        /// 数据库
        /// </summary>
        public static IDataService DataService
        {
            get
            {
                IDataService dataService = AppContext.Context["DataService"] as IDataService;

                return dataService;
            }
        }

        /// <summary>
        /// 日志类
        /// </summary>
        public static ILoggingService Log
        {
            get
            {
                ILoggingService log = AppContext.Context["Log"] as ILoggingService;

                return log;
            }
        }

        /// <summary>
        /// XML序列化
        /// </summary>
        public static ISimpleSerializer XmlService
        {
            get
            {
                ISimpleSerializer xmlService = AppContext.Context["XmlService"] as ISimpleSerializer;

                return xmlService;
            }
        }

        /// <summary>
        /// 正则表达式
        /// </summary>
        public static IRegex Regex
        {
            get
            {
                IRegex regex = AppContext.Context["Regex"] as IRegex;

                return regex;
            }
        }
    }
}
