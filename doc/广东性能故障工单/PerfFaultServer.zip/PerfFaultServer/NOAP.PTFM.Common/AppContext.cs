﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Context;
using Spring.Context.Support;

namespace NOAP.PTFM.Common
{
    public sealed class AppContext
    {
        private static IApplicationContext context;

        public static IApplicationContext Context
        {
            get
            {
                if (context == null)
                {
                    context = ContextRegistry.GetContext();
                }
                return context;
            }

        }
    }
}
