﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Common
{
    public interface IRegex
    {
        bool IsMatch(string text, string key);
        System.Collections.Generic.IList<string> Match(string text, string key);
        System.Collections.Generic.IList<string> Match(string text, string[] keys);
    }
}
