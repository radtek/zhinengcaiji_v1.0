﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Common
{
    public interface ILoggingService
    {
        void Debug(object message);
        void DebugFormatted(string format, params object[] args);

        void Error(object message);
        void Error(object message, Exception exception);
        void ErrorFormatted(string format, params object[] args);

        void Fatal(object message, Exception exception);
        void Fatal(object message);
        void FatalFormatted(string format, params object[] args);

        void Info(object message);
        void InfoFormatted(string format, params object[] args);

        void Warn(object message, Exception exception);
        void Warn(object message);
        void WarnFormatted(string format, params object[] args);
    }
}
