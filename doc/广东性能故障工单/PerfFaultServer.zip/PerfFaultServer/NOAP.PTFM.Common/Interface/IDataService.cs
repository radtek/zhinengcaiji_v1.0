﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace NOAP.PTFM.Common
{
    public interface IDataService
    {
        DataTable GetDataTable(string sql);
        int ExecNonQuery(string sql);
    }
}
