﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.Common
{
    public interface ISimpleSerializer
    {
        /// <summary>
        /// 序列化对象
        /// </summary>
        /// <typeparam name="T">对象类型</typeparam>
        /// <param name="t">对象</param>
        /// <returns></returns>
        string Serialize<T>(T t);

        /// <summary>
        /// 反序列化为对象
        /// </summary>
        /// <param name="type">对象类型</param>
        /// <param name="s">对象序列化后的Xml字符串</param>
        /// <returns></returns>
        object Deserialize(Type type, string s);

    }
}
