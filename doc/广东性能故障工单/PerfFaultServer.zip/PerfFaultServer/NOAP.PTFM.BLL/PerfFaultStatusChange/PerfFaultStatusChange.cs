﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Common;
using NOAP.PTFM.Model;
using NOAP.PTFM.DAL;

namespace NOAP.PTFM.BLL
{
    public class PerfFaultStatusChange
    {
        /// <summary>
        /// 电子运维调用接口主方法，根据参数字符串，反序列化为相应对象,判断是否完成故障修复
        /// </summary>
        /// <param name="xmlPara">电子运维传过来的参数字符串</param>
        /// <param name="strip">电子运维的IP字符串形式</param>
        /// <returns>序列化后的确认故障是否修复的对象</returns>
        public string ExecStatusChange(string xmlPara, string strip)
        {
            //故障单状态改变对象
            StatusChangeModel scm = null;
            //身份验证对象
            AuthModel authm = null;
            //具体状态对象
            PscParaModel pscpm = null;
            //返回对象
            PscReturnModel pscrm = null;

            //返回的序列化字符串
            string strxml = string.Empty;
            //验证XML参数的格式是否符合
            try
            {
                scm = ServiceLocator.XmlService.Deserialize(typeof(StatusChangeModel), xmlPara) as StatusChangeModel;
            }
            catch (Exception)
            {
                pscrm = new PscReturnModel();
                pscrm.FaultCode = "";
                pscrm.IsSuccess = 0;
                pscrm.ResultDesc = "输入参数格式不正确。";
                pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                return FaultPublic.GetReplaceXml(strxml);
            }

            //获取接口认证信息和参数内容
            authm = scm.Auth;
            pscpm = scm.Para;

            //验证认证信息
            string strdesc = string.Empty;
            if (CheckAuth(authm, strip, out strdesc))
            {
                //更新工单管理表，工单的状态、更新时间，插入工单日志表。
                IPerfFaultStatusChange pscimpl = new PerfFaultStatusChangeImpl();
                string statusStr = pscimpl.UpdateState(pscpm);
                if (statusStr == "11")
                {
                    pscrm = new PscReturnModel();
                    pscrm.FaultCode = pscpm.FaultCode;
                    pscrm.IsSuccess = 1;
                    pscrm.ResultDesc = "故障单状态同步成功。";
                    pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                    return FaultPublic.GetReplaceXml(strxml);
                }
                else if (statusStr == "22")
                {
                    pscrm = new PscReturnModel();
                    pscrm.FaultCode = pscpm.FaultCode;
                    pscrm.IsSuccess = 0;
                    pscrm.ResultDesc = "故障单已结单，状态同步失败。";
                    pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                    return FaultPublic.GetReplaceXml(strxml);
                }
                else if (statusStr == "00")
                {
                    pscrm = new PscReturnModel();
                    pscrm.FaultCode = pscpm.FaultCode;
                    pscrm.IsSuccess = 0;
                    pscrm.ResultDesc = "故障单状态同步失败，无此母单号。";
                    pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                    return FaultPublic.GetReplaceXml(strxml);
                }
                else
                {
                    pscrm = new PscReturnModel();
                    pscrm.FaultCode = pscpm.FaultCode;
                    pscrm.IsSuccess = 0;
                    pscrm.ResultDesc = "故障单状态同步失败，接口更新时报错。";
                    pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                    return FaultPublic.GetReplaceXml(strxml);
                }
            }
            else
            {
                pscrm = new PscReturnModel();
                pscrm.FaultCode = pscpm.FaultCode;
                pscrm.IsSuccess = 0;
                pscrm.ResultDesc = "认证信息验证失败，" + strdesc;
                pscrm.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                strxml = ServiceLocator.XmlService.Serialize<PscReturnModel>(pscrm);
                return FaultPublic.GetReplaceXml(strxml);
            }
        }

        private bool CheckAuth(AuthModel authm, string strip, out string strdesc)
        {
            string strauth = string.Empty;
            PscReturnModel pscreturn = new PscReturnModel();
            try
            {
                strauth = authm.FlowId.ToString() + strip + "NetOp";
                string authkey = FaultPublic.GetAuthKey(strauth);
                if (authkey == authm.AuthKey.ToUpper())
                {
                    strdesc = "";
                    return true;
                }
                else
                {
                    strdesc = "认证信息为" + strauth + "，EOMS计算key值为" + authm.AuthKey + "，NOAP计算key值为" + authkey;
                    return false;
                }
            }
            catch (Exception e)
            {
                strdesc = e.Message;
                return false;
            }
        }
    }
}
