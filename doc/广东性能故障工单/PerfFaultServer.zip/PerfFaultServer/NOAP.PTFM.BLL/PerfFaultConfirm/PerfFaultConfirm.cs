﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.DAL;
using NOAP.PTFM.Model;
using NOAP.PTFM.Common;

namespace NOAP.PTFM.BLL
{
    public class PerfFaultConfirm
    {
        public void ConfirmNotice(int cityid, int modelid)
        {
            //获取待评估的工单，通知电子运维接口
            IPerfFaultConfirm pfcimpl = new PerfFaultConfirmImpl();
            List<PfcParaModel> listcpm = pfcimpl.GetConfirmOrder(cityid, modelid);

            foreach (PfcParaModel cpmitem in listcpm)
            {
                //通知电子运维故障清除通知接口
                PfcReturnModel eomsreturn = NoticeEoms(cpmitem);

                //更新工单状态和工单日志
                IPerfFaultConfirm pfc = new PerfFaultConfirmImpl();
                pfc.UpdateState(cpmitem, eomsreturn);
            }        
        }

        private PfcReturnModel NoticeEoms(PfcParaModel cpmitem)
        {
            //生成电子运维故障恢复通知接口所需XML格式的字符串
            ConfirmNoticeModel cnm = new ConfirmNoticeModel();
            cnm.Auth = FaultPublic.GetNewAuth();
            cnm.Para = cpmitem;
            string comlaint = ServiceLocator.XmlService.Serialize<ConfirmNoticeModel>(cnm);

            comlaint = FaultPublic.GetReplaceXml(comlaint);

            ServiceLocator.Log.Info(comlaint);

            //调用eoms接口
            eoms.netOptimize eoms = new eoms.netOptimize();
            string returnstr = eoms.confirmNotice(comlaint);

            ServiceLocator.Log.Info(returnstr);

            //反序列化eoms返回的XML成实体对象
            PfcReturnModel rpm = ServiceLocator.XmlService.Deserialize(typeof(PfcReturnModel), returnstr) as PfcReturnModel;
            return rpm;
        }
    }
}
