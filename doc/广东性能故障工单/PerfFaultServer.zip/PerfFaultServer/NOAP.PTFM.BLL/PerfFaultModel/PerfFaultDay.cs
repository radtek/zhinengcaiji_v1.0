﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;
using NOAP.PTFM.Common;
using NOAP.PTFM.DAL;
using System.Configuration;
using System.Threading;

namespace NOAP.PTFM.BLL
{
    public class PerfFaultDay : IPerfFault
    {
        string date = string.Empty;
        IPerfFaultModel ipfm;

        #region IPerfFault 成员
        public void ExecStart()
        {
            ipfm = new PerfFaultModelImpl();

            ExecTaskModel();

            ExecSendModel();            
        }
        #endregion

        private void ExecTaskModel()
        {
            ServiceLocator.Log.Info("天性能故障工单模型查询开始");
            List<DayPerfFaultModel> listPTFM = null;
            try
            {
                listPTFM = ipfm.GetDayPerfFaultModel();
            }
            catch (Exception ex)
            {
                ServiceLocator.Log.Error(string.Format("查询天工单模型出错，错误信息：{0}。", ex.Message));
                return;
            } 
            ServiceLocator.Log.Info("天性能故障工单模型查询完成");

            foreach (DayPerfFaultModel dayitem in listPTFM)
            {
                foreach (SqlPerfFaultModel sqlitem in dayitem.IfSql)
                {
                    try
                    {
                        int number = ipfm.ExceSql(sqlitem.FuncSql);
                        ServiceLocator.Log.Info(string.Format("【{0}】【{1}】，共有【{2}】条记录。", dayitem.CityID, sqlitem.FuncDepict, number.ToString()));
                    }
                    catch (Exception ex)
                    {
                        ServiceLocator.Log.Error(string.Format("【{0}】执行【{1}】出错，错误信息：{2}。", dayitem.CityID, sqlitem.FuncDepict,ex.Message));
                    }
                }
            }
        }

        private void ExecSendModel()
        {
            ServiceLocator.Log.Info("天性能故障派单模型查询开始");
            List<DayPerfSendModel> listPSM = null;
            try
            {
                listPSM = ipfm.GetDayPerfSendModel();
            }
            catch (Exception ex)
            {
                ServiceLocator.Log.Error(string.Format("查询天派单模型出错，错误信息：{0}。", ex.Message));
                return;
            } 
            ServiceLocator.Log.Info("天性能故障派单模型查询完成");
            foreach (DayPerfSendModel dayitems in listPSM)
            {
                foreach (SqlPerfFaultModel sqlitems in dayitems.IfSql)
                {
                    try
                    {
                        int number = ipfm.ExceSql(sqlitems.FuncSql);
                        ServiceLocator.Log.Info(string.Format("【{0}】【{1}】，共有【{2}】条记录。", dayitems.CityID, sqlitems.FuncDepict, number.ToString()));
                    }
                    catch (Exception ex)
                    {
                        ServiceLocator.Log.Error(string.Format("【{0}】执行【{1}】出错，错误信息：{2}。", dayitems.CityID, sqlitems.FuncDepict,ex.Message));
                    }
                }

                try
                {
                    Thread.Sleep(10000);
                    ServiceLocator.Log.Info("开始派单，地市：【" + dayitems.CityID + "】 故障模型：【" + dayitems.ModelID + "】");

                    //调用派单接口自动派单
                    string url = ConfigurationManager.AppSettings["SendOrderUrl"] + "?CityID={0}&ModelID={1}";
                    System.Net.WebClient web = new System.Net.WebClient();
                    web.OpenRead(string.Format(url, dayitems.CityID, dayitems.ModelID));
                    ServiceLocator.Log.Info("派单完成");
                }
                catch (Exception ex)
                {
                    ServiceLocator.Log.Info("派单出错，错误信息：" + ex.Message);
                }

            }
 
        }
    }
}
