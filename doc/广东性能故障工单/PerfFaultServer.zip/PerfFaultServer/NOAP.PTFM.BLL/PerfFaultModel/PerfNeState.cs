﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Common;
using NOAP.PTFM.Model;
using NOAP.PTFM.DAL;

namespace NOAP.PTFM.BLL
{
    public class PerfNeState
    {
        public void AutoNeState()
        {
            ServiceLocator.Log.Info("自动计算网元等级开始");
            IPerfFaultModel ipfm = new PerfFaultModelImpl();
            List<PerfNeStateModel> listPNS = null;
            try
            {
                listPNS = ipfm.GetPerfNeStateModel();
            }
            catch (Exception ex)
            {
                ServiceLocator.Log.Error(string.Format("查询网元等级计算模型出错，错误信息：{0}。", ex.Message));
                return;
            }
            ServiceLocator.Log.Info("自动计算网元等级完成");

            foreach (PerfNeStateModel neitem in listPNS)
            {
                foreach (SqlPerfFaultModel sqlitem in neitem.IfSql)
                {
                    try
                    {
                        int number = ipfm.ExceSql(sqlitem.FuncSql);
                        ServiceLocator.Log.Info(string.Format("【{0}】【{1}】，共有【{2}】条记录。", neitem.CityID, sqlitem.FuncDepict, number.ToString()));

                    }
                    catch (Exception ex)
                    {
                        ServiceLocator.Log.Error(string.Format("【{0}】执行【{1}】出错，错误信息：{2}。", neitem.CityID, sqlitem.FuncDepict,ex.Message));
                    }
                }
            }            
        }
    }
}
