﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOAP.PTFM.BLL
{
    public interface IPerfFault
    {
        void ExecStart();
    }
}
