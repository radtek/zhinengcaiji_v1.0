﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Common;
using NOAP.PTFM.DAL;
using NOAP.PTFM.Model;
using System.Configuration;
using System.Data;
using System.Net;
using System.Threading;

namespace NOAP.PTFM.BLL
{
    public class PerfFaultHour : IPerfFault
    {

        string datetime = string.Empty;
        IPerfFaultModel ipfm;

        #region IPerfFault 成员

        public void ExecStart()
        {
            ipfm = new PerfFaultModelImpl();

            ExecTaskModel();

            ExecSendModel();

            //补派单
            ExecSendAgain();
        }
        #endregion

        private void ExecTaskModel()
        {
            ServiceLocator.Log.Info("小时性能故障工单模型查询开始");
            List<HourPerfFaultModel> listPFM = null;
            try
            {
                listPFM = ipfm.GetHourPerfFaultModel();
            }
            catch (Exception ex)
            {
                ServiceLocator.Log.Error(string.Format("查询小时工单模型出错，错误信息：{0}。", ex.Message));
                return;
            }            
            ServiceLocator.Log.Info("小时性能故障工单模型查询完成");

            foreach (HourPerfFaultModel houritem in listPFM)
            {
                foreach (SqlPerfFaultModel sqlitem in houritem.IfSql)
                {
                    try
                    {
                        int number = ipfm.ExceSql(sqlitem.FuncSql);
                        ServiceLocator.Log.Info(string.Format("【{0}】【{1}】，共有【{2}】条记录。", houritem.CityID, sqlitem.FuncDepict, number.ToString()));

                    }
                    catch (Exception ex)
                    {
                        ServiceLocator.Log.Error(string.Format("【{0}】执行【{1}】出错，错误信息：{0}。", houritem.CityID, sqlitem.FuncDepict,ex.Message));
                    }
                }
            }
        }

        private void ExecSendModel()
        {
            //ServiceLocator.Log.Info("小时性能故障派单模型查询开始");
            //ServiceLocator.Log.Info("小时性能故障派单模型查询完成");

            //ServiceLocator.Log.Info("根据小时性能故障派单模型过滤数据开始");
            //ServiceLocator.Log.Info("根据小时性能故障派单模型过滤数据完成");

        }

        private void ExecSendAgain()
        {
            //对派单失败的故障单进行补派单
            int num = Convert.ToInt32(ConfigurationManager.AppSettings["SendOrderNum"]);
            string url = ConfigurationManager.AppSettings["SendOrderUrl"] + "?OrderID={0}";

            //1、更新超过补派单次数的故障单
            ipfm.UpdateFailureOrder(num);

            ServiceLocator.Log.Info("补派单开始");
            //2、获取派单失败的故障单号，调用派单接口派单
            DataTable dt = ipfm.GetFailureOrder(num);
            if (dt != null)
            {
                int count = dt.Rows.Count;

                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        DataRow row = dt.Rows[i];
                        try
                        {
                            //Thread.Sleep(5000);
                            //调用派单接口自动派单                            
                            System.Net.WebClient web = new System.Net.WebClient();
                            web.OpenRead(string.Format(url, row["ORDER_ID"].ToString().Trim()));
                            
                        }
                        catch (Exception ex)
                        {
                            ServiceLocator.Log.Info("【" + row["ORDER_ID"].ToString().Trim() + "】补派单失败，错误信息：" + ex.Message);
                        }
                    }
                }
            }
            ServiceLocator.Log.Info("补派单完成");
        }
    }
}
