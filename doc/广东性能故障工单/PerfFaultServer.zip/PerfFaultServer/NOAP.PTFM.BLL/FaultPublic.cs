﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;

namespace NOAP.PTFM.BLL
{
    public static class FaultPublic
    {
        public static AuthModel GetNewAuth()
        {
            AuthModel auth = new AuthModel();
            string strip = GetIp();
            string key = auth.FlowId.ToString() + strip + "NetOp";
            auth.AuthKey = GetAuthKey(key);
            return auth;
        }

        public static string GetReplaceXml(string strxml)
        {
            string xml = string.Empty;
            xml = strxml.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            xml = xml.Replace(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"","");
            xml = xml.Replace("\r\n", "");
            return xml;
        }

        public static string GetAuthKey(string key)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider md = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] value, hash;
            value = System.Text.Encoding.UTF8.GetBytes(key);
            hash = md.ComputeHash(value);
            md.Clear();
            string temp = string.Empty;
            for (int i = 0, len = hash.Length; i < len; i++)
            {
                temp += hash[i].ToString("X").PadLeft(2, '0');
            }
            return temp;
        }

        private static string GetIp()
        {
            string hostip = string.Empty;
            string hostname = System.Net.Dns.GetHostName();
            System.Net.IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(hostname);
            for (int i = 0; i < ipEntry.AddressList.Length; i++)
            {
                string[] strsip = ipEntry.AddressList[i].ToString().Split('.');
                if (strsip.Length == 4)
                {
                    hostip = ipEntry.AddressList[i].ToString();
                    break;
                }
            }
            return hostip;
        }
    }
}
