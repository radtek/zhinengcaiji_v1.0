﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NOAP.PTFM.Model;
using NOAP.PTFM.Common;
using NOAP.PTFM.DAL;

namespace NOAP.PTFM.BLL
{
    public class PerfFaultSend
    {
        /// <summary>
        /// 根据工单ID获取派单实体对象，一般是用户手工派单。
        /// </summary>
        /// <param name="orderid">工单ID</param>
        public PfsReturnModel SendOrder(string orderid)
        {
            //根据工单ID获取待派单信息，返回派单实体对象
            IPerfFaultSend pfsi = new PerfFaultSendImpl();
            PfsParaModel cpm = pfsi.GetComplaintPara(orderid);
            PfsReturnModel rmp = new PfsReturnModel();
            try
            {
                rmp = SendOrderToEoms(cpm);
            }
            catch (Exception ex)
            {
                rmp.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                rmp.FaultCode = "";
                rmp.IsSuccess = 2;
                rmp.ResultDesc = "调用EOMS故障申告接口失败，错误信息：" + ex.Message;
                ServiceLocator.Log.Info(rmp.ResultDesc);
            }

            //更新工单管理表和工单日志表
            pfsi.UpdateOrderManage(orderid, rmp);

            //更新该网元同类型的其它手工派单未不派单状态
            if (rmp.IsSuccess == 1)
            {
                pfsi.UpdateUserSendOrder(orderid, cpm.SysProbCauseId);
            }

            return rmp;
        }

        /// <summary>
        /// 获取派单实体对象，一般是系统自动派单
        /// </summary>
        /// <param name="cityid">城市ID</param>
        /// <param name="modelid">派单模型ID</param>
        public void SendOrder(int cityid, int modelid)
        {
            //根据工单ID获取待派单信息，返回派单实体对象
            PerfFaultSendImpl pfsi = new PerfFaultSendImpl();
            List<PfsParaModel> cpm = pfsi.GetComplaintPara(cityid, modelid);
            foreach (PfsParaModel cpmitem in cpm)
            {
                PfsReturnModel rmp = new PfsReturnModel();
                try
                {
                    rmp = SendOrderToEoms(cpmitem);
                }
                catch (Exception ex)
                {
                    rmp.CreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    rmp.FaultCode = "";
                    rmp.IsSuccess = 2;
                    rmp.ResultDesc = "调用EOMS故障申告接口失败，错误信息：" + ex.Message;
                    ServiceLocator.Log.Info(rmp.ResultDesc);
                }

                //更新工单管理表和工单日志表
                pfsi.UpdateOrderManage(cpmitem.OutSystemNo, rmp);
            }

        }

        private PfsReturnModel SendOrderToEoms(PfsParaModel pfspm)
        {
            //生成电子运维派单接口所需XML格式的字符串
            ComplaintModel cpm = new ComplaintModel();
            cpm.Auth = FaultPublic.GetNewAuth();
            cpm.Para = pfspm;
            string comlaint = ServiceLocator.XmlService.Serialize<ComplaintModel>(cpm);

            comlaint = FaultPublic.GetReplaceXml(comlaint);

            ServiceLocator.Log.Info(comlaint);

            //调用eoms接口
            eoms.netOptimize eoms = new eoms.netOptimize();
            string returnstr = eoms.complaint(comlaint);

            ServiceLocator.Log.Info(returnstr);

            //反序列化eoms返回的XML成实体对象
            PfsReturnModel rpm = ServiceLocator.XmlService.Deserialize(typeof(PfsReturnModel), returnstr) as PfsReturnModel;
            return rpm;
        }
    }
}
