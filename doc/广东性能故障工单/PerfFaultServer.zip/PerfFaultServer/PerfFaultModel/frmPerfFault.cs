﻿using System;
using System.Windows.Forms;
using NOAP.PTFM.Common;
using NOAP.PTFM.BLL;

namespace PerfFaultModel
{
    public partial class frmPerfFault : Form
    {
        public frmPerfFault()
        {
            InitializeComponent();
        }

        private void frmPerfFault_Load(object sender, EventArgs e)
        {
            ServiceLocator.Log.Info("性能故障筛选模型服务启动");

            //PerfFaultHour hourPF = new PerfFaultHour();
            //hourPF.ExecStart();

            //PerfFaultDay dayPF = new PerfFaultDay();
            //dayPF.ExecStart();

            PerfFaultWeek weekPF = new PerfFaultWeek();
            weekPF.ExecStart();

            //PerfNeState pns = new PerfNeState();
            //pns.AutoNeState();
        }

        private void frmPerfFault_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("PerfFaultModel");
            foreach (System.Diagnostics.Process p in ps)
            {
                p.Kill();
            }
        }
    }
}
