﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using NOAP.PTFM.BLL;
using NOAP.PTFM.Common;
using NOAP.PTFM.Model;
using NOAP.PTFM.DAL;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int count = Request.QueryString.Count;
        PerfFaultSend pfs = null;
        switch (count)
        {
            case 1:
                string orderid = Request.QueryString["OrderID"];
                Label2.Text = "正在派单，故障单号：【" + orderid + "】";
                Label3.Text = "正在派单，请稍候...";
                ServiceLocator.Log.Info("手工派单开始，故障单号：【" + orderid + "】");
                pfs = new PerfFaultSend();
                PfsReturnModel eomsreturn = pfs.SendOrder(orderid);
                if (eomsreturn.IsSuccess == 1)
                {
                    Label3.Text = "派单成功，母单号：【" + eomsreturn.FaultCode + "】";
                    ServiceLocator.Log.Info("手工派单成功，母单号：【" + eomsreturn.FaultCode + "】");
                }
                else
                {
                    Label3.Text = "派单失败，描述：【" + eomsreturn.ResultDesc + "】";
                    ServiceLocator.Log.Info("手工派单失败，描述：【" + eomsreturn.ResultDesc + "】");
                }
                break;
            case 2:
                int cityid = Convert.ToInt32(Request.QueryString["CityID"]);
                int modelid = Convert.ToInt32(Request.QueryString["ModelID"]);
                //自动派单，调用eoms故障申告接口。
                ServiceLocator.Log.Info("地市：【" + cityid.ToString() + "】 故障模型：【" + modelid.ToString() + "】");
                ServiceLocator.Log.Info("自动派单开始");
                pfs = new PerfFaultSend();
                pfs.SendOrder(cityid, modelid);
                ServiceLocator.Log.Info("自动派单结束");
                //过了评估期自动结单，调用eoms故障恢复通知
                ServiceLocator.Log.Info("故障恢复通知开始");
                PerfFaultConfirm pfc = new PerfFaultConfirm();
                pfc.ConfirmNotice(cityid, modelid);
                ServiceLocator.Log.Info("故障恢复通知结束");
                break;
            default:
                //pfs = new PerfFaultSend();
                //string sorderid = "GZ0104108081003035220020111106";
                //pfs.SendOrder(sorderid);

                ////自动派单，调用eoms故障申告接口。
                //pfs = new PerfFaultSend();
                //pfs.SendOrder(20, 210104020);

                ////过了评估期自动结单，调用eoms故障恢复通知
                //PerfFaultConfirm pfcm = new PerfFaultConfirm();
                //pfcm.ConfirmNotice(20, 210104020);
                break;
        }
    }
}
